/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.1.2-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: shopdb
-- ------------------------------------------------------
-- Server version	12.1.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `tmcb_cntct`
--

DROP TABLE IF EXISTS `tmcb_cntct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_cntct` (
  `id` varchar(50) NOT NULL,
  `cntct_users` varchar(50) NOT NULL,
  `cntct_bsins` varchar(50) NOT NULL,
  `cntct_ctype` varchar(50) NOT NULL,
  `cntct_sorce` varchar(50) NOT NULL,
  `cntct_cntnm` varchar(200) NOT NULL,
  `cntct_cntps` varchar(50) DEFAULT NULL,
  `cntct_cntno` varchar(50) DEFAULT NULL,
  `cntct_email` varchar(50) DEFAULT NULL,
  `cntct_tinno` varchar(50) NOT NULL,
  `cntct_trade` varchar(50) NOT NULL,
  `cntct_ofadr` varchar(300) DEFAULT NULL,
  `cntct_fcadr` varchar(300) DEFAULT NULL,
  `cntct_tarea` varchar(50) NOT NULL,
  `cntct_dzone` varchar(50) NOT NULL,
  `cntct_cntry` varchar(50) DEFAULT NULL,
  `cntct_cntad` varchar(50) DEFAULT NULL,
  `cntct_dspct` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_crlmt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_pybln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_adbln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_crbln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cntct_crusr` varchar(50) NOT NULL,
  `cntct_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cntct_upusr` varchar(50) NOT NULL,
  `cntct_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cntct_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_cntct`
--

LOCK TABLES `tmcb_cntct` WRITE;
/*!40000 ALTER TABLE `tmcb_cntct` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmcb_cntct` VALUES
('08eb3501-fcd0-4d99-84c3-ce5309bfe613','user1','business1','Supplier','Local','Bengal Fresh Foods','Nusrat Jahan','01822-000002','email@sgd.com','TIN-123456','TRADE-123456','Chittagong Wholesale Market','Chittagong Wholesale Market','sirajganj-sadar','sirajganj','Bangladesh','0',10.000000,20000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-14 09:17:52','user1','2026-01-31 10:14:56',6),
('11f1664d-5d03-4724-a4dd-57ad3e01ad1a','user1','business1','Customer','Local','Al Noor Store','Javed Hasan','01623-100104','email@sgd.com','TIN-123456','TRADE-123456','Sylhet Zindabazar','Sylhet Zindabazar','bogra-sadar','bogra','Bangladesh','0',10.000000,25000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-18 11:24:23','user1','2026-02-05 09:58:53',5),
('267bb3aa-9177-43d2-8d8b-e0137578cf98','user1','business1','Supplier','Local','Dhaka Agro Traders','Md. Kamal Hossain','01711-000001','email@email.com','','','Kawran Bazar, Dhaka','Kawran Bazar, Dhaka','araihazar','narayanganj','Bangladesh','0',0.000000,20000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-09 12:02:10','user1','2026-01-31 10:14:56',4),
('41981c62-d7fc-4238-a8f1-8c70bd2c1e0e','user1','business1','Customer','Local','Bismillah Traders','Hafiz Uddin','01921-100103','','TIN-123-123','TRADE-123-123','Cumilla Sadar','Cumilla Sadar','araihazar','narayanganj','Bangladesh','0',0.000000,25000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-18 11:24:02','user1','2026-02-05 09:59:08',4),
('521e18fc-b57a-48c4-a0a7-d7772edb4b76','user1','business1','Customer','Local','M/S Amin Enterprise','Aminul Islam','01534-100105','','','','Khulna Boyra','Khulna Boyra','kachpur','narayanganj','Bangladesh','0',10.000000,25000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-18 11:24:45','user1','2026-02-05 09:59:20',3),
('639611f4-97e5-4589-904e-190ef11f7f4e','user1','business1','Supplier','Local','Jisan Dairy Source','Akhi Khatun','01555-000005','','','','Mirpur-10, Dhaka','Mirpur-10, Dhaka','enayetpur','sirajganj','Bangladesh','0',0.000000,25000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-18 11:10:29','user1','2026-01-31 10:14:56',2),
('6a0619ca-84e9-4df5-b225-7dd7acb91b86','user1','business1','Supplier','Local','Green Farm Ltd.','Abdul Karim','01933-000003','','','','Bogura Sadar, Bogura','Bogura Sadar, Bogura','bogra-sadar','bogra','Bangladesh','0',10.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-18 11:09:12','user1','2026-01-31 10:14:56',2),
('be93309a-ec2b-40d0-9c62-8abe7796b547','user1','business1','Supplier','Local','Golden Grain Supply','Rashed Mahmud','01644-000004','','','','Jashore Industrial Area','Jashore Industrial Area','kamarkhanda','sirajganj','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-18 11:09:47','user1','2026-01-31 10:14:56',2),
('both','user1','business1','Both','Local','Both A/C','Both A/C','Both A/C','Both A/C','','','Both A/C','Both A/C','sherpur','bogra','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-09 13:04:25','user1','2026-01-31 10:14:56',3),
('c370a9f5-7ccf-4e2d-9d7a-7d5873293ddc','user1','business1','Customer','Local','Shapno Mini Mart','Farzana Islam','01819-100102','email@sgd.com','','','Uttara Sector 7, Dhaka','Uttara Sector 7, Dhaka','belkuchi','sirajganj','Bangladesh','0',5.000000,25000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-14 09:23:59','user1','2026-02-05 09:59:30',4),
('d5eefaf0-9979-4edf-8fbd-68f3157c4105','user1','business1','Customer','Local','Rahman General Store','Anisur Rahman','01712-100101','email@email.com','','','Mohammadpur, Dhaka','Mohammadpur, Dhaka','adamdighi','bogra','Bangladesh','0',0.000000,50000.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-09 12:02:29','user1','2026-01-31 10:14:56',4),
('internal','user1','business1','Internal','Local','Internal A/C','Internal A/C','Internal A/C','Internal A/C','','','Internal A/C','Internal A/C','sherpur','bogra','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-09 13:04:25','user1','2026-01-31 10:14:56',3);
/*!40000 ALTER TABLE `tmcb_cntct` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmcb_dzone`
--

DROP TABLE IF EXISTS `tmcb_dzone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_dzone` (
  `id` varchar(50) NOT NULL,
  `dzone_users` varchar(50) NOT NULL,
  `dzone_bsins` varchar(50) NOT NULL,
  `dzone_cntry` varchar(50) NOT NULL,
  `dzone_dname` varchar(50) NOT NULL,
  `dzone_actve` tinyint(1) NOT NULL DEFAULT 1,
  `dzone_crusr` varchar(50) NOT NULL,
  `dzone_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `dzone_upusr` varchar(50) NOT NULL,
  `dzone_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dzone_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_dzone`
--

LOCK TABLES `tmcb_dzone` WRITE;
/*!40000 ALTER TABLE `tmcb_dzone` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmcb_dzone` VALUES
('bogra','user1','business1','Bangladesh','Bogra',1,'user1','2026-01-25 04:45:54','user1','2026-01-31 10:15:30',1),
('narayanganj','user1','business1','Bangladesh','Narayanganj',1,'user1','2026-01-25 04:45:54','user1','2026-01-31 10:15:30',1),
('sirajganj','user1','business1','Bangladesh','Sirajganj',1,'user1','2026-01-25 04:45:54','user1','2026-01-31 10:15:30',1);
/*!40000 ALTER TABLE `tmcb_dzone` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmcb_rutes`
--

DROP TABLE IF EXISTS `tmcb_rutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_rutes` (
  `id` varchar(50) NOT NULL,
  `rutes_users` varchar(50) NOT NULL,
  `rutes_bsins` varchar(50) NOT NULL,
  `rutes_rname` varchar(50) NOT NULL,
  `rutes_dname` varchar(50) NOT NULL,
  `rutes_sraid` varchar(50) NOT NULL,
  `rutes_lvdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rutes_ttcnt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_odval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_dlval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_clval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_duval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_actve` tinyint(1) NOT NULL DEFAULT 1,
  `rutes_crusr` varchar(50) NOT NULL,
  `rutes_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rutes_upusr` varchar(50) NOT NULL,
  `rutes_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rutes_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_rutes`
--

LOCK TABLES `tmcb_rutes` WRITE;
/*!40000 ALTER TABLE `tmcb_rutes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmcb_rutes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmcb_tarea`
--

DROP TABLE IF EXISTS `tmcb_tarea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_tarea` (
  `id` varchar(50) NOT NULL,
  `tarea_users` varchar(50) NOT NULL,
  `tarea_bsins` varchar(50) NOT NULL,
  `tarea_dzone` varchar(50) NOT NULL,
  `tarea_tname` varchar(50) NOT NULL,
  `tarea_actve` tinyint(1) NOT NULL DEFAULT 1,
  `tarea_crusr` varchar(50) NOT NULL,
  `tarea_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tarea_upusr` varchar(50) NOT NULL,
  `tarea_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tarea_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_tarea`
--

LOCK TABLES `tmcb_tarea` WRITE;
/*!40000 ALTER TABLE `tmcb_tarea` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmcb_tarea` VALUES
('adamdighi','user1','business1','bogra','Adamdighi',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('araihazar','user1','business1','narayanganj','Araihazar',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('bandar','user1','business1','narayanganj','Bandar',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('belkuchi','user1','business1','sirajganj','Belkuchi',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('bhairob','user1','business1','narayanganj','Bhairob',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('bogra-sadar','user1','business1','bogra','Bogra Sadar',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('chauhali','user1','business1','sirajganj','Chauhali',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('dhunat','user1','business1','bogra','Dhunat',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('dhupchanchia','user1','business1','bogra','Dhupchanchia',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('enayetpur','user1','business1','sirajganj','Enayetpur',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('gabtali','user1','business1','bogra','Gabtali',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('jamuna-river','user1','business1','sirajganj','Jamuna River',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('kachpur','user1','business1','narayanganj','Kachpur',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('kahaloo','user1','business1','bogra','Kahaloo',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('kamarkhanda','user1','business1','sirajganj','Kamarkhanda',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('kazipur','user1','business1','sirajganj','Kazipur',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('nandigram','user1','business1','bogra','Nandigram',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('narayanganj-city-corporation','user1','business1','narayanganj','Narayanganj City Corporation',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('narayanganj-sadar','user1','business1','narayanganj','Narayanganj Sadar',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('raiganj','user1','business1','sirajganj','Raiganj',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('rupganj','user1','business1','narayanganj','Rupganj',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('sariakandi','user1','business1','bogra','Sariakandi',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('shahjadpur','user1','business1','sirajganj','Shahjadpur',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('shajahanpur','user1','business1','bogra','Shajahanpur',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('sherpur','user1','business1','bogra','Sherpur',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('shibganj','user1','business1','bogra','Shibganj',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('sirajganj-sadar','user1','business1','sirajganj','Sirajganj Sadar',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('sonargaon','user1','business1','narayanganj','Sonargaon',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('sonatala','user1','business1','bogra','Sonatala',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1),
('tarash','user1','business1','sirajganj','Tarash',1,'user1','2026-01-25 04:57:51','user1','2026-01-31 10:16:17',1);
/*!40000 ALTER TABLE `tmcb_tarea` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmeb_cinvc`
--

DROP TABLE IF EXISTS `tmeb_cinvc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmeb_cinvc` (
  `id` varchar(50) NOT NULL,
  `cinvc_minvc` varchar(50) NOT NULL,
  `cinvc_bitem` varchar(50) NOT NULL,
  `cinvc_items` varchar(50) NOT NULL,
  `cinvc_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_lprat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_notes` varchar(50) DEFAULT NULL,
  `cinvc_attrb` varchar(300) DEFAULT NULL,
  `cinvc_srcnm` varchar(50) NOT NULL,
  `cinvc_refid` varchar(50) NOT NULL,
  `cinvc_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cinvc_crusr` varchar(50) NOT NULL,
  `cinvc_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cinvc_upusr` varchar(50) NOT NULL,
  `cinvc_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cinvc_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmeb_cinvc`
--

LOCK TABLES `tmeb_cinvc` WRITE;
/*!40000 ALTER TABLE `tmeb_cinvc` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmeb_cinvc` VALUES
('4ba0de4b-b501-4a76-8fc6-bf074cd50fee','cdb0a7ab-0a31-4d10-aeb7-b2a06a91e427','f241e3b7-3f83-42f4-ac10-af8def91799a','38b496e9-6652-4324-8331-ba0ecb0cfeae',75.000000,10.000000,750.000000,0.000000,0.000000,5.000000,37.500000,75.000000,787.500000,55.000000,'','{}','Inventory Stock','f241e3b7-3f83-42f4-ac10-af8def91799a',1,'user1','2026-02-05 09:49:47','user1','2026-02-05 09:49:47',1),
('5e33c32f-cb45-4050-b778-3e621790efd7','cdb0a7ab-0a31-4d10-aeb7-b2a06a91e427','9a04c7bb-e9d8-4adf-8eff-1fe92e43c971','fa1b188a-c075-4b90-bbea-37e3733f50bb',950.000000,10.000000,9500.000000,0.000000,0.000000,5.000000,475.000000,950.000000,9975.000000,750.000000,'','{}','Purchase Receipt','e9c8cc55-42b3-4e66-b83a-dcc41ce02e77',1,'user1','2026-02-05 09:49:47','user1','2026-02-05 09:49:47',1),
('8ad89a4a-fb74-4df1-88a1-e319c54b5843','cdb0a7ab-0a31-4d10-aeb7-b2a06a91e427','282533ed-53cf-496a-8611-c452785371fd','42ccd66a-70db-4c7f-93c4-36261a8f064f',380.000000,10.000000,3800.000000,0.000000,0.000000,5.000000,190.000000,380.000000,3990.000000,300.000000,'','{}','Inventory Stock','282533ed-53cf-496a-8611-c452785371fd',1,'user1','2026-02-05 09:49:47','user1','2026-02-05 09:49:47',1),
('92f5bce9-7959-48fb-8196-11f0233aa55a','3c8eb29d-ceb8-481a-b62a-4bb15b57749a','282533ed-53cf-496a-8611-c452785371fd','42ccd66a-70db-4c7f-93c4-36261a8f064f',380.000000,10.000000,3800.000000,0.000000,0.000000,5.000000,190.000000,390.000000,3990.000000,300.000000,'','{}','Inventory Stock','282533ed-53cf-496a-8611-c452785371fd',1,'user1','2026-02-05 10:00:33','user1','2026-02-05 10:00:33',1),
('ef4ab973-7558-49a6-9211-ed9561f281a2','02113046-37f4-4167-aa6d-3aa09ef453e0','282533ed-53cf-496a-8611-c452785371fd','42ccd66a-70db-4c7f-93c4-36261a8f064f',380.000000,10.000000,3800.000000,0.000000,0.000000,5.000000,190.000000,385.000000,3990.000000,300.000000,'','{}','Inventory Stock','282533ed-53cf-496a-8611-c452785371fd',1,'user1','2026-02-05 09:52:06','user1','2026-02-05 09:52:06',1);
/*!40000 ALTER TABLE `tmeb_cinvc` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmeb_expns`
--

DROP TABLE IF EXISTS `tmeb_expns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmeb_expns` (
  `id` varchar(50) NOT NULL,
  `expns_users` varchar(50) NOT NULL,
  `expns_bsins` varchar(50) NOT NULL,
  `expns_cntct` varchar(50) NOT NULL,
  `expns_refid` varchar(50) NOT NULL,
  `expns_refno` varchar(50) NOT NULL,
  `expns_srcnm` varchar(50) NOT NULL,
  `expns_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `expns_inexc` tinyint(1) NOT NULL DEFAULT 1,
  `expns_notes` varchar(100) DEFAULT NULL,
  `expns_xpamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `expns_actve` tinyint(1) NOT NULL DEFAULT 1,
  `expns_crusr` varchar(50) NOT NULL,
  `expns_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `expns_upusr` varchar(50) NOT NULL,
  `expns_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expns_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmeb_expns`
--

LOCK TABLES `tmeb_expns` WRITE;
/*!40000 ALTER TABLE `tmeb_expns` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmeb_expns` VALUES
('38b04f55-28cf-41aa-b06e-afc54ab10984','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','02113046-37f4-4167-aa6d-3aa09ef453e0','SI-050226-00002','Sales Invoice','2026-02-05 00:00:00',2,'',30.000000,1,'user1','2026-02-05 09:52:06','user1','2026-02-05 09:52:06',1),
('738e6c5f-716e-4364-9462-b6177631697a','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','02113046-37f4-4167-aa6d-3aa09ef453e0','SI-050226-00002','Sales Invoice','2026-02-05 00:00:00',1,'',20.000000,1,'user1','2026-02-05 09:52:06','user1','2026-02-05 09:52:06',1),
('94adc505-9997-4554-a2d5-fa5585a6c5d8','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','3c8eb29d-ceb8-481a-b62a-4bb15b57749a','SI-050226-00003','Sales Invoice','2026-02-05 00:00:00',1,'Courier Bill',100.000000,1,'user1','2026-02-05 10:00:33','user1','2026-02-05 10:00:33',1);
/*!40000 ALTER TABLE `tmeb_expns` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmeb_minvc`
--

DROP TABLE IF EXISTS `tmeb_minvc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmeb_minvc` (
  `id` varchar(50) NOT NULL,
  `minvc_users` varchar(50) NOT NULL,
  `minvc_bsins` varchar(50) NOT NULL,
  `minvc_cntct` varchar(50) NOT NULL,
  `minvc_trnno` varchar(50) NOT NULL,
  `minvc_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `minvc_refno` varchar(50) DEFAULT NULL,
  `minvc_trnte` varchar(100) DEFAULT NULL,
  `minvc_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_rtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_actve` tinyint(1) NOT NULL DEFAULT 1,
  `minvc_crusr` varchar(50) NOT NULL,
  `minvc_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `minvc_upusr` varchar(50) NOT NULL,
  `minvc_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `minvc_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmeb_minvc`
--

LOCK TABLES `tmeb_minvc` WRITE;
/*!40000 ALTER TABLE `tmeb_minvc` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmeb_minvc` VALUES
('02113046-37f4-4167-aa6d-3aa09ef453e0','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','SI-050226-00002','2026-02-05 00:00:00','','',3800.000000,0.000000,190.000000,1,20.000000,30.000000,0.000000,4010.000000,4010.000000,4010.000000,0.000000,0.000000,1,1,0,0,0,1,'user1','2026-02-05 09:52:06','user1','2026-02-05 09:52:06',1),
('3c8eb29d-ceb8-481a-b62a-4bb15b57749a','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','SI-050226-00003','2026-02-05 00:00:00','','',3800.000000,0.000000,190.000000,1,100.000000,0.000000,0.000000,4090.000000,4090.000000,4000.000000,90.000000,0.000000,2,1,0,0,0,1,'user1','2026-02-05 10:00:33','user1','2026-02-05 10:00:33',1),
('cdb0a7ab-0a31-4d10-aeb7-b2a06a91e427','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','SI-050226-00001','2026-02-05 00:00:00','','',14050.000000,0.000000,702.500000,1,0.000000,0.000000,0.000000,14752.500000,14752.500000,14753.000000,0.000000,0.000000,1,1,0,0,0,1,'user1','2026-02-05 09:49:47','user1','2026-02-05 09:49:47',1);
/*!40000 ALTER TABLE `tmeb_minvc` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_attrb`
--

DROP TABLE IF EXISTS `tmib_attrb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_attrb` (
  `id` varchar(50) NOT NULL,
  `attrb_users` varchar(50) NOT NULL,
  `attrb_aname` varchar(50) NOT NULL,
  `attrb_dtype` varchar(50) NOT NULL,
  `attrb_actve` tinyint(1) NOT NULL DEFAULT 1,
  `attrb_crusr` varchar(50) NOT NULL,
  `attrb_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `attrb_upusr` varchar(50) NOT NULL,
  `attrb_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `attrb_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_attrb`
--

LOCK TABLES `tmib_attrb` WRITE;
/*!40000 ALTER TABLE `tmib_attrb` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_attrb` VALUES
('color','user1','Color','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('expiry','user1','Expiry','date',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('fabric','user1','Fabric','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('flavor','user1','Flavor','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('height','user1','Height','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('imei','user1','IMEI','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('model','user1','Model','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('serialno','user1','Serial No','number',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('size','user1','Size','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('weight','user1','Weight','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1),
('width','user1','Width','text',1,'user1','2026-01-25 07:38:19','user1','2026-01-31 10:17:08',1);
/*!40000 ALTER TABLE `tmib_attrb` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_bitem`
--

DROP TABLE IF EXISTS `tmib_bitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_bitem` (
  `id` varchar(50) NOT NULL,
  `bitem_users` varchar(50) NOT NULL,
  `bitem_items` varchar(50) NOT NULL,
  `bitem_bsins` varchar(50) NOT NULL,
  `bitem_lprat` decimal(20,6) DEFAULT 0.000000,
  `bitem_dprat` decimal(20,6) DEFAULT 0.000000,
  `bitem_mcmrp` decimal(20,6) DEFAULT 0.000000,
  `bitem_sddsp` decimal(20,6) DEFAULT 0.000000,
  `bitem_snote` varchar(100) DEFAULT NULL,
  `bitem_gstkq` decimal(20,6) DEFAULT 0.000000,
  `bitem_bstkq` decimal(20,6) DEFAULT 0.000000,
  `bitem_istkq` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bitem_mnqty` decimal(20,6) DEFAULT 1.000000,
  `bitem_mxqty` decimal(20,6) DEFAULT 1.000000,
  `bitem_pbqty` decimal(20,6) DEFAULT 0.000000,
  `bitem_sbqty` decimal(20,6) DEFAULT 0.000000,
  `bitem_mpric` decimal(20,6) DEFAULT 0.000000,
  `bitem_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bitem_crusr` varchar(50) NOT NULL,
  `bitem_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bitem_upusr` varchar(50) NOT NULL,
  `bitem_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bitem_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_bitem`
--

LOCK TABLES `tmib_bitem` WRITE;
/*!40000 ALTER TABLE `tmib_bitem` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_bitem` VALUES
('1248204a-e407-4245-8952-924a1f832354','user1','4b019cba-eda8-4ad3-a8ac-ece0e6478ffe','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:56:36','user1','2026-02-02 11:50:24',1),
('19debe39-1eaa-4cb1-ba16-3f361ff455ca','user1','e2e70dc1-9814-400c-8774-2b6b186b79e5','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:58:15','user1','2026-02-02 05:57:45',1),
('1b0483c5-ed8f-43ce-b128-9dbf717e8e67','user1','8873e069-eea6-4f9e-acf0-dd1cb658f9c8','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:55:41','user1','2026-01-31 10:55:41',1),
('2188dcd0-244b-4750-ad51-f86397b196f1','user1','dfe206f2-b3a3-4d6c-8b3c-7402582348eb','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:04','user1','2026-01-31 10:59:04',1),
('228076b3-b3df-4270-a1b3-a2520267818c','user1','485d61c3-e84e-418b-b91b-2171c17f0391','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:58:06','user1','2026-01-31 10:58:06',1),
('282533ed-53cf-496a-8611-c452785371fd','user1','42ccd66a-70db-4c7f-93c4-36261a8f064f','business1',300.000000,0.000000,380.000000,0.000000,'',70.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,20.000000,1,'user1','2026-01-31 10:57:58','user1','2026-02-05 10:00:33',1),
('28738f75-f676-4f53-bb43-b74638699553','user1','e483bc2d-6ccd-4b72-8603-775dcd275249','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:58:49','user1','2026-01-31 10:58:49',1),
('586345fd-6f26-4577-90ab-dfb8bc49e187','user1','471d3f7f-e3e5-4585-bdbf-5f0a35b05a93','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 11:00:06','user1','2026-01-31 11:00:06',1),
('59dd7e4d-3748-4ee0-9531-8eb73cf03fed','user1','940f8010-5d38-4de4-b66f-d12958ff9ecf','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:57:22','user1','2026-01-31 10:57:22',1),
('75860dc3-c9f8-43b9-a20f-f78104602fdf','user1','4b100c2e-68a6-467b-94b7-617a6c7b43dc','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:55','user1','2026-01-31 10:59:55',1),
('85f84fc9-2d92-4327-81b6-31a4c6c6cc8a','user1','e45670a3-981c-47c2-bd6a-a02bd8c0d7b0','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:58:57','user1','2026-01-31 10:58:57',1),
('8ce55060-f46d-445f-bcc1-7fb9d5f5f38e','user1','b3da1017-bea4-44fd-ad13-110e92a48965','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:41','user1','2026-01-31 10:59:41',1),
('9a04c7bb-e9d8-4adf-8eff-1fe92e43c971','user1','fa1b188a-c075-4b90-bbea-37e3733f50bb','business1',750.000000,0.000000,950.000000,0.000000,'',0.000000,0.000000,90.000000,0.000000,0.000000,0.000000,0.000000,65.000000,1,'user1','2026-01-31 10:57:44','user1','2026-02-05 09:49:47',1),
('9a765ccf-f3c5-480a-863d-492c7d9fa196','user1','4dab149a-e220-4cd8-a061-7660ab0168bb','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 11:00:36','user1','2026-01-31 11:00:36',1),
('b9b0e3b5-a1df-43ea-a736-04a54f5df89b','user1','75b05c78-9b6b-42ba-aafa-e76e22f67722','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:58:31','user1','2026-01-31 10:58:31',1),
('bde13886-7498-42b9-bc4d-19bcb62ed918','user1','f7126510-80c0-416b-a34e-3a514e54d030','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:57:00','user1','2026-01-31 10:57:00',1),
('bf05a1d1-2b12-46e8-bf24-5e7edde46136','user1','24614ec4-8ab0-4b50-b3c7-9f154a124770','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:47','user1','2026-02-01 14:22:53',1),
('c6fe2a29-7725-4db6-9bed-840c04301d0e','user1','ad014a04-77d0-4f46-acc9-dee2b02c64f2','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:56:46','user1','2026-01-31 10:56:46',1),
('d2b89636-0c00-4c61-aa9b-08ff5f37cac7','user1','f949a24a-3ff8-4349-9ca0-f853de9226c7','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:13','user1','2026-01-31 10:59:13',1),
('df364d84-6063-44c7-8b26-bb9d81fc0bc1','user1','0e5de4e6-86dd-453a-8b94-963ee305e860','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:21','user1','2026-01-31 10:59:21',1),
('dfa047a4-4799-460d-ae14-74697a8f0466','user1','ae0a4ae3-77f6-4357-8ca9-c05cc1796a7e','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:58:42','user1','2026-01-31 10:58:42',1),
('e1e36ac3-d2b5-4f7b-a258-2c3ffcacd131','user1','2bee4dba-5f29-4e65-b772-718c677e326c','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:56:51','user1','2026-01-31 10:56:51',1),
('eff83204-5f40-4920-9d42-67a27ec6a1a5','user1','2c047e91-44f6-48bc-a591-9ab00deb7b72','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 10:59:30','user1','2026-01-31 10:59:30',1),
('f241e3b7-3f83-42f4-ac10-af8def91799a','user1','38b496e9-6652-4324-8331-ba0ecb0cfeae','business1',55.000000,0.000000,75.000000,0.000000,'',90.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,11.750000,1,'user1','2026-01-31 10:57:36','user1','2026-02-05 09:49:47',1),
('f4445732-0c3d-4388-b30a-b77cd0151b14','user1','940f8010-5d38-4de4-b66f-d12958ff9ec2','business1',0.000000,0.000000,0.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,1,'user1','2026-01-31 11:00:20','user1','2026-01-31 11:00:20',1);
/*!40000 ALTER TABLE `tmib_bitem` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_ctgry`
--

DROP TABLE IF EXISTS `tmib_ctgry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_ctgry` (
  `id` varchar(50) NOT NULL,
  `ctgry_users` varchar(50) NOT NULL,
  `ctgry_ctgnm` varchar(50) NOT NULL,
  `ctgry_actve` tinyint(1) NOT NULL DEFAULT 1,
  `ctgry_crusr` varchar(50) NOT NULL,
  `ctgry_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ctgry_upusr` varchar(50) NOT NULL,
  `ctgry_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ctgry_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_ctgry`
--

LOCK TABLES `tmib_ctgry` WRITE;
/*!40000 ALTER TABLE `tmib_ctgry` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_ctgry` VALUES
('204e4887-0af6-4908-add0-240ea380a53b','user1','Household Essentials',1,'user1','2026-01-11 05:06:00','user1','2026-01-31 10:27:26',1),
('36886293-b080-44dc-9c8e-fed94ad161d3','user1','Rice & Grain',1,'user1','2026-01-11 05:04:19','user1','2026-01-31 10:27:26',1),
('3ed137d4-3863-407a-8f4a-dd1000479780','user1','Dairy Products',1,'user1','2026-01-11 05:04:25','user1','2026-01-31 10:27:26',1),
('b1df68d6-2888-42c7-a3a8-cdaedadf5408','user1','Toys and Gears',1,'user1','2026-01-11 05:04:47','user1','2026-01-31 10:27:26',1),
('e69fe3b2-784f-44d5-9d88-4c228704242f','user1','Eggs & Poultry',1,'user1','2026-01-11 05:04:10','user1','2026-01-31 10:27:26',1),
('feacdbbe-2519-4975-96fe-ad18c7899b53','user1','Beverages & Snacks',1,'user1','2026-01-11 05:03:50','user1','2026-01-31 10:27:26',1);
/*!40000 ALTER TABLE `tmib_ctgry` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_ctrsf`
--

DROP TABLE IF EXISTS `tmib_ctrsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_ctrsf` (
  `id` varchar(50) NOT NULL,
  `ctrsf_mtrsf` varchar(50) NOT NULL,
  `ctrsf_bitem` varchar(50) NOT NULL,
  `ctrsf_items` varchar(50) NOT NULL,
  `ctrsf_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_notes` varchar(50) DEFAULT NULL,
  `ctrsf_attrb` varchar(300) DEFAULT NULL,
  `ctrsf_rtqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_slqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_ohqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_srcnm` varchar(50) NOT NULL,
  `ctrsf_refid` varchar(50) NOT NULL,
  `ctrsf_actve` tinyint(1) NOT NULL DEFAULT 1,
  `ctrsf_crusr` varchar(50) NOT NULL,
  `ctrsf_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ctrsf_upusr` varchar(50) NOT NULL,
  `ctrsf_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ctrsf_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_ctrsf`
--

LOCK TABLES `tmib_ctrsf` WRITE;
/*!40000 ALTER TABLE `tmib_ctrsf` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmib_ctrsf` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_expns`
--

DROP TABLE IF EXISTS `tmib_expns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_expns` (
  `id` varchar(50) NOT NULL,
  `expns_users` varchar(50) NOT NULL,
  `expns_bsins` varchar(50) NOT NULL,
  `expns_cntct` varchar(50) NOT NULL,
  `expns_refid` varchar(50) NOT NULL,
  `expns_refno` varchar(50) NOT NULL,
  `expns_srcnm` varchar(50) NOT NULL,
  `expns_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `expns_inexc` tinyint(1) NOT NULL DEFAULT 1,
  `expns_notes` varchar(100) DEFAULT NULL,
  `expns_xpamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `expns_actve` tinyint(1) NOT NULL DEFAULT 1,
  `expns_crusr` varchar(50) NOT NULL,
  `expns_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `expns_upusr` varchar(50) NOT NULL,
  `expns_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expns_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_expns`
--

LOCK TABLES `tmib_expns` WRITE;
/*!40000 ALTER TABLE `tmib_expns` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmib_expns` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_items`
--

DROP TABLE IF EXISTS `tmib_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_items` (
  `id` varchar(50) NOT NULL,
  `items_users` varchar(50) NOT NULL,
  `items_icode` varchar(50) DEFAULT NULL,
  `items_bcode` varchar(50) DEFAULT NULL,
  `items_hscod` varchar(50) DEFAULT NULL,
  `items_iname` varchar(100) NOT NULL,
  `items_idesc` varchar(100) DEFAULT NULL,
  `items_puofm` varchar(50) NOT NULL,
  `items_dfqty` int(11) NOT NULL DEFAULT 1,
  `items_suofm` varchar(50) NOT NULL,
  `items_ctgry` varchar(50) NOT NULL,
  `items_itype` varchar(50) NOT NULL,
  `items_trcks` tinyint(1) NOT NULL DEFAULT 0,
  `items_sdvat` decimal(4,2) DEFAULT 0.00,
  `items_costp` decimal(4,2) DEFAULT 0.00,
  `items_image` varchar(50) DEFAULT NULL,
  `items_nofbi` int(11) NOT NULL DEFAULT 0,
  `items_actve` tinyint(1) NOT NULL DEFAULT 1,
  `items_crusr` varchar(50) NOT NULL,
  `items_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `items_upusr` varchar(50) NOT NULL,
  `items_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `items_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_items`
--

LOCK TABLES `tmib_items` WRITE;
/*!40000 ALTER TABLE `tmib_items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_items` VALUES
('0e5de4e6-86dd-453a-8b94-963ee305e860','user1','HE-003','HE-003','HE-003','Floor Cleaner','Floor Cleaner','1f240f2c-50ab-407f-b77d-0ce95922fd6c',1,'1f240f2c-50ab-407f-b77d-0ce95922fd6c','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,7.50,16.00,NULL,1,1,'user1','2026-01-18 12:08:34','user1','2026-01-31 10:59:21',1),
('24614ec4-8ab0-4b50-b3c7-9f154a124770','user1','RG-003','RG-003','RG-003','Basmati Rice','Basmati Rice','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,5.00,16.00,NULL,1,1,'user1','2026-01-12 06:16:06','user1','2026-01-31 10:59:47',1),
('2bee4dba-5f29-4e65-b772-718c677e326c','user1','BS-004','BS-004','BS-004','Potato Chips','Potato Chips','344eb4c8-48c4-475b-b74c-307a0e492622',20,'f5ccd3c1-fd1e-4f0e-93be-59dd878c881a','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,10.00,20.00,NULL,1,1,'user1','2026-01-18 12:23:51','user1','2026-01-31 10:56:51',1),
('2c047e91-44f6-48bc-a591-9ab00deb7b72','user1','RG-005','RG-005','RG-005','Masur Dal','Masur Dal','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,5.00,15.00,NULL,1,1,'user1','2026-01-18 11:49:45','user1','2026-01-31 10:59:30',1),
('38b496e9-6652-4324-8331-ba0ecb0cfeae','user1','DP-001','DP-001','DP-001','Fresh Milk','Fresh Milk','1f240f2c-50ab-407f-b77d-0ce95922fd6c',1,'1f240f2c-50ab-407f-b77d-0ce95922fd6c','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,5.00,15.00,NULL,1,1,'user1','2026-01-18 11:51:08','user1','2026-01-31 10:57:36',1),
('42ccd66a-70db-4c7f-93c4-36261a8f064f','user1','DP-003','DP-003','DP-003','Yogurt','Yogurt','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,5.00,20.00,NULL,1,1,'user1','2026-01-18 11:53:02','user1','2026-01-31 10:57:58',1),
('471d3f7f-e3e5-4585-bdbf-5f0a35b05a93','user1','HE-005','HE-005','HE-005','Tissue Roll','Tissue Roll','344eb4c8-48c4-475b-b74c-307a0e492622',6,'78a63632-6a35-49ab-8cac-4b5c0d4fb418','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,7.50,18.00,NULL,1,1,'user1','2026-01-18 12:10:46','user1','2026-01-31 11:00:06',1),
('485d61c3-e84e-418b-b91b-2171c17f0391','user1','DP-004','DP-004','DP-004','Butter','Butter','344eb4c8-48c4-475b-b74c-307a0e492622',1,'344eb4c8-48c4-475b-b74c-307a0e492622','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,5.00,18.00,NULL,1,1,'user1','2026-01-18 11:54:16','user1','2026-01-31 10:58:06',1),
('4b019cba-eda8-4ad3-a8ac-ece0e6478ffe','user1','BS-002','BS-002','BS-002','Mineral Water 1L','Mineral Water 1L','344eb4c8-48c4-475b-b74c-307a0e492622',12,'c1ab2f8e-5030-40a4-85a3-569ad7cc6dd7','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,10.00,14.00,NULL,1,1,'user1','2026-01-18 12:21:19','user1','2026-01-31 10:56:36',1),
('4b100c2e-68a6-467b-94b7-617a6c7b43dc','user1','HE-004','HE-004','HE-004','Toilet Cleaner','Toilet Cleaner','344eb4c8-48c4-475b-b74c-307a0e492622',6,'78a63632-6a35-49ab-8cac-4b5c0d4fb418','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,7.50,20.00,NULL,1,1,'user1','2026-01-18 12:09:36','user1','2026-01-31 10:59:55',1),
('4dab149a-e220-4cd8-a061-7660ab0168bb','user1','RG-002','RG-002','RG-002','Nazirshail Rice','Nazirshail Rice','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,5.00,14.00,NULL,1,1,'user1','2026-01-12 06:20:57','user1','2026-01-31 11:00:36',1),
('75b05c78-9b6b-42ba-aafa-e76e22f67722','user1','HE-001','HE-001','HE-001','Laundry Soap','Laundry Soap','344eb4c8-48c4-475b-b74c-307a0e492622',12,'78a63632-6a35-49ab-8cac-4b5c0d4fb418','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,7.50,20.00,NULL,1,1,'user1','2026-01-18 12:05:41','user1','2026-01-31 10:58:31',1),
('8873e069-eea6-4f9e-acf0-dd1cb658f9c8','user1','BS-001','BS-001','BS-001','Soft Drink 250ml','Soft Drink 250ml','344eb4c8-48c4-475b-b74c-307a0e492622',24,'f5d78785-c08b-46b7-a77f-dcf1a8700dd0','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,10.00,15.00,NULL,1,1,'user1','2026-01-18 12:20:20','user1','2026-01-31 11:11:12',1),
('940f8010-5d38-4de4-b66f-d12958ff9ec2','user1','RG-001','RG-001','RG-001','Miniket Rice','Miniket Rice','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,5.00,15.00,NULL,1,1,'user1','2026-01-11 06:06:23','user1','2026-01-31 11:00:20',1),
('940f8010-5d38-4de4-b66f-d12958ff9ecf','user1','EP-003','EP-003','EP-003','Layer Egg (Dozen)','Layer Egg (Dozen)','61accd0f-ebd7-4c2c-9e33-ba5f92e091d1',30,'f5d78785-c08b-46b7-a77f-dcf1a8700dd0','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,5.00,15.00,NULL,1,1,'user1','2026-01-11 06:06:23','user1','2026-01-31 10:57:22',1),
('ad014a04-77d0-4f46-acc9-dee2b02c64f2','user1','BS-003','BS-003','BS-003','Juice Pack','Juice Pack','344eb4c8-48c4-475b-b74c-307a0e492622',10,'cdd3a6c9-d31b-4a41-8762-69700e2a1108','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,10.00,18.00,NULL,1,1,'user1','2026-01-18 12:22:34','user1','2026-01-31 10:56:46',1),
('ae0a4ae3-77f6-4357-8ca9-c05cc1796a7e','user1','EP-001','EP-001','EP-001','Layer Egg','Layer Egg','344eb4c8-48c4-475b-b74c-307a0e492622',12,'61accd0f-ebd7-4c2c-9e33-ba5f92e091d1','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,5.00,20.00,NULL,1,1,'user1','2026-01-12 06:17:33','user1','2026-01-31 10:58:42',1),
('b3da1017-bea4-44fd-ad13-110e92a48965','user1','RG-004','RG-004','RG-004','Wheat','Wheat','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,5.00,12.00,NULL,1,1,'user1','2026-01-18 11:49:00','user1','2026-01-31 10:59:41',1),
('dfe206f2-b3a3-4d6c-8b3c-7402582348eb','user1','EP-002','EP-002','EP-002','Duck Egg','Duck Egg','344eb4c8-48c4-475b-b74c-307a0e492622',12,'61accd0f-ebd7-4c2c-9e33-ba5f92e091d1','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,5.00,18.00,NULL,1,1,'user1','2026-01-12 06:38:50','user1','2026-01-31 10:59:04',1),
('e2e70dc1-9814-400c-8774-2b6b186b79e5','user1','DP-005','DP-005','DP-005','Cheese Slice','Cheese Slice','344eb4c8-48c4-475b-b74c-307a0e492622',10,'50d3582c-909a-4818-afd7-54a8db8c1a44','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,5.00,18.00,NULL,1,1,'user1','2026-01-18 11:55:20','user1','2026-01-31 10:58:15',1),
('e45670a3-981c-47c2-bd6a-a02bd8c0d7b0','user1','EP-004','EP-004','EP-004','Broiler Chicken','Broiler Chicken','f13c1fb3-3493-4640-9b13-02bd824b4977',1000,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,5.00,12.00,NULL,1,1,'user1','2026-01-11 06:38:46','user1','2026-01-31 10:58:57',1),
('e483bc2d-6ccd-4b72-8603-775dcd275249','user1','EP-005','EP-005','EP-005','Deshi Chicken','Deshi Chicken','f13c1fb3-3493-4640-9b13-02bd824b4977',1000,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,5.00,10.00,NULL,1,1,'user1','2026-01-12 06:12:16','user1','2026-01-31 10:58:49',1),
('f7126510-80c0-416b-a34e-3a514e54d030','user1','BS-005','BS-005','BS-005','Biscuit','Biscuit','344eb4c8-48c4-475b-b74c-307a0e492622',12,'50d3582c-909a-4818-afd7-54a8db8c1a44','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,10.00,15.00,NULL,1,1,'user1','2026-01-18 12:24:41','user1','2026-01-31 10:57:00',1),
('f949a24a-3ff8-4349-9ca0-f853de9226c7','user1','HE-002','HE-002','HE-002','Dishwashing Liquid','Dishwashing Liquid','1f240f2c-50ab-407f-b77d-0ce95922fd6c',1,'1f240f2c-50ab-407f-b77d-0ce95922fd6c','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,7.50,18.00,NULL,1,1,'user1','2026-01-18 12:06:48','user1','2026-01-31 10:59:13',1),
('fa1b188a-c075-4b90-bbea-37e3733f50bb','user1','DP-002','DP-002','DP-002','Powder Milk','Powder Milk','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',1,5.00,18.00,NULL,1,1,'user1','2026-01-18 11:52:20','user1','2026-01-31 14:17:25',1);
/*!40000 ALTER TABLE `tmib_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_iuofm`
--

DROP TABLE IF EXISTS `tmib_iuofm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_iuofm` (
  `id` varchar(50) NOT NULL,
  `iuofm_users` varchar(50) NOT NULL,
  `iuofm_untnm` varchar(50) NOT NULL,
  `iuofm_untgr` varchar(50) DEFAULT NULL,
  `iuofm_actve` tinyint(1) NOT NULL DEFAULT 1,
  `iuofm_crusr` varchar(50) NOT NULL,
  `iuofm_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `iuofm_upusr` varchar(50) NOT NULL,
  `iuofm_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `iuofm_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_iuofm`
--

LOCK TABLES `tmib_iuofm` WRITE;
/*!40000 ALTER TABLE `tmib_iuofm` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_iuofm` VALUES
('024a6dbf-85cb-48d6-91e0-41f4b977bcd4','user1','Ml','Volume',1,'user1','2026-01-18 12:07:30','user1','2026-01-31 10:11:36',1),
('1f240f2c-50ab-407f-b77d-0ce95922fd6c','user1','Ltr','Volume',1,'user1','2026-01-11 04:40:38','user1','2026-01-31 10:11:36',1),
('2276a903-fc68-4c43-8448-8ceab9aee99d','user1','Bulk','Mass',1,'user1','2026-01-12 06:39:04','user1','2026-01-31 10:11:36',1),
('22b30ed6-ee7a-421d-a9a3-dc6c710b9229','user1','Kg','Weight',1,'user1','2026-01-11 04:43:41','user1','2026-01-31 10:11:36',1),
('2993fee8-3e34-4e2e-8cb9-63461934a6ef','user1','Inch','Length',1,'user1','2026-01-14 08:34:51','user1','2026-01-31 10:11:36',1),
('324249dc-432a-44b8-8191-cb1bfe2ad530','user1','Ton','Weight',1,'user1','2026-01-14 08:33:44','user1','2026-01-31 10:11:36',1),
('344eb4c8-48c4-475b-b74c-307a0e492622','user1','Pcs','Countable',1,'user1','2026-01-11 04:40:18','user1','2026-01-31 10:11:36',1),
('50d3582c-909a-4818-afd7-54a8db8c1a44','user1','Pack','Countable',1,'user1','2026-01-11 04:40:31','user1','2026-01-31 10:11:36',1),
('53640e3f-20b8-44a6-8872-5844630bfed0','user1','Gal','Volume',1,'user1','2026-01-14 08:34:28','user1','2026-01-31 10:11:36',1),
('61accd0f-ebd7-4c2c-9e33-ba5f92e091d1','user1','Dzn','Countable',1,'user1','2026-01-11 04:40:57','user1','2026-01-31 10:11:36',1),
('674e6bee-5066-415a-9f35-b6e72f978a08','user1','Yard','Length',1,'user1','2026-01-11 04:43:59','user1','2026-01-31 10:11:36',1),
('78a63632-6a35-49ab-8cac-4b5c0d4fb418','user1','Box','Countable',1,'user1','2026-01-11 04:40:52','user1','2026-01-31 10:11:36',1),
('9233b04b-3367-4205-9b3c-bb569e1bebb6','user1','Inch','Length',1,'user1','2026-01-14 08:34:34','user1','2026-01-31 10:11:36',1),
('a08ee30c-cb3d-467c-aff6-d347c74c9e8b','user1','Cm','Length',1,'user1','2026-01-14 08:34:39','user1','2026-01-31 10:11:36',1),
('abc985a3-68b1-4b98-825b-ebe79903d033','user1','Bottle','Countable',1,'user1','2026-01-14 08:33:58','user1','2026-01-31 10:11:36',1),
('c1ab2f8e-5030-40a4-85a3-569ad7cc6dd7','user1','Cage','Countable',1,'user1','2026-01-14 08:34:18','user1','2026-01-31 10:11:36',1),
('cdd3a6c9-d31b-4a41-8762-69700e2a1108','user1','Ctn','Countable',1,'user1','2026-01-11 04:40:23','user1','2026-01-31 10:11:36',1),
('f13c1fb3-3493-4640-9b13-02bd824b4977','user1','Gm','Weight',1,'user1','2026-01-14 08:33:32','user1','2026-01-31 10:11:36',1),
('f2fa8d7c-69d4-439d-9dea-66fba7aac17b','user1','Bag','Mass',1,'user1','2026-01-14 08:34:10','user1','2026-01-31 10:11:36',1),
('f5ccd3c1-fd1e-4f0e-93be-59dd878c881a','user1','Poly','Countable',1,'user1','2026-01-14 08:25:05','user1','2026-01-31 10:11:36',1),
('f5d78785-c08b-46b7-a77f-dcf1a8700dd0','user1','Crate','Mass',1,'user1','2026-01-14 08:33:25','user1','2026-01-31 10:11:36',1);
/*!40000 ALTER TABLE `tmib_iuofm` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_mtrsf`
--

DROP TABLE IF EXISTS `tmib_mtrsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_mtrsf` (
  `id` varchar(50) NOT NULL,
  `mtrsf_users` varchar(50) NOT NULL,
  `mtrsf_bsins` varchar(50) NOT NULL,
  `mtrsf_bsins_to` varchar(50) NOT NULL,
  `mtrsf_trnno` varchar(50) NOT NULL,
  `mtrsf_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mtrsf_refno` varchar(50) DEFAULT NULL,
  `mtrsf_trnte` varchar(100) DEFAULT NULL,
  `mtrsf_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mtrsf_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mtrsf_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mtrsf_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `mtrsf_isrcv` tinyint(1) NOT NULL DEFAULT 0,
  `mtrsf_rcusr` varchar(50) DEFAULT NULL,
  `mtrsf_rcdat` datetime DEFAULT NULL,
  `mtrsf_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mtrsf_crusr` varchar(50) NOT NULL,
  `mtrsf_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mtrsf_upusr` varchar(50) NOT NULL,
  `mtrsf_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mtrsf_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_mtrsf`
--

LOCK TABLES `tmib_mtrsf` WRITE;
/*!40000 ALTER TABLE `tmib_mtrsf` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmib_mtrsf` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_cbkng`
--

DROP TABLE IF EXISTS `tmpb_cbkng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_cbkng` (
  `id` varchar(50) NOT NULL,
  `cbkng_mbkng` varchar(50) NOT NULL,
  `cbkng_bitem` varchar(50) NOT NULL,
  `cbkng_items` varchar(50) NOT NULL,
  `cbkng_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_notes` varchar(50) DEFAULT NULL,
  `cbkng_attrb` varchar(300) DEFAULT NULL,
  `cbkng_cnqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_rcqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_pnqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cbkng_crusr` varchar(50) NOT NULL,
  `cbkng_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cbkng_upusr` varchar(50) NOT NULL,
  `cbkng_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cbkng_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_cbkng`
--

LOCK TABLES `tmpb_cbkng` WRITE;
/*!40000 ALTER TABLE `tmpb_cbkng` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_cbkng` VALUES
('22be751a-e91e-4b0a-994f-a686e1383ecb','c4714648-8827-4d9a-b665-5bad97ed5e35','9a04c7bb-e9d8-4adf-8eff-1fe92e43c971','fa1b188a-c075-4b90-bbea-37e3733f50bb',750.000000,100.000000,75000.000000,0.000000,0.000000,5.000000,3750.000000,750.000000,78750.000000,'','{}',0.000000,100.000000,0.000000,1,'user1','2026-02-05 09:30:47','user1','2026-02-05 09:31:12',1),
('ee7a4b40-451b-4022-b930-061cd7b39bfa','c4714648-8827-4d9a-b665-5bad97ed5e35','f241e3b7-3f83-42f4-ac10-af8def91799a','38b496e9-6652-4324-8331-ba0ecb0cfeae',55.000000,100.000000,5500.000000,0.000000,0.000000,5.000000,275.000000,55.000000,5775.000000,'','{}',0.000000,100.000000,0.000000,1,'user1','2026-02-05 09:30:47','user1','2026-02-05 09:31:12',1);
/*!40000 ALTER TABLE `tmpb_cbkng` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_cinvc`
--

DROP TABLE IF EXISTS `tmpb_cinvc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_cinvc` (
  `id` varchar(50) NOT NULL,
  `cinvc_minvc` varchar(50) NOT NULL,
  `cinvc_bitem` varchar(50) NOT NULL,
  `cinvc_items` varchar(50) NOT NULL,
  `cinvc_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_notes` varchar(50) DEFAULT NULL,
  `cinvc_attrb` varchar(300) DEFAULT NULL,
  `cinvc_rtqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_slqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_ohqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cinvc_crusr` varchar(50) NOT NULL,
  `cinvc_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cinvc_upusr` varchar(50) NOT NULL,
  `cinvc_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cinvc_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_cinvc`
--

LOCK TABLES `tmpb_cinvc` WRITE;
/*!40000 ALTER TABLE `tmpb_cinvc` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_cinvc` VALUES
('38dda382-59eb-46d0-b15e-84d7f81e8ee1','0f97e570-b98a-4a78-8ca8-51f488ecefd1','282533ed-53cf-496a-8611-c452785371fd','42ccd66a-70db-4c7f-93c4-36261a8f064f',300.000000,100.000000,30000.000000,0.000000,0.000000,5.000000,1500.000000,300.000000,31500.000000,'','{}',0.000000,0.000000,100.000000,1,'user1','2026-02-05 09:32:53','user1','2026-02-05 09:32:53',1);
/*!40000 ALTER TABLE `tmpb_cinvc` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_crcpt`
--

DROP TABLE IF EXISTS `tmpb_crcpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_crcpt` (
  `id` varchar(50) NOT NULL,
  `crcpt_mrcpt` varchar(50) NOT NULL,
  `crcpt_bitem` varchar(50) NOT NULL,
  `crcpt_items` varchar(50) NOT NULL,
  `crcpt_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_notes` varchar(50) DEFAULT NULL,
  `crcpt_attrb` varchar(300) DEFAULT NULL,
  `crcpt_rtqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_slqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_ohqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_cbkng` varchar(50) NOT NULL,
  `crcpt_actve` tinyint(1) NOT NULL DEFAULT 1,
  `crcpt_crusr` varchar(50) NOT NULL,
  `crcpt_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crcpt_upusr` varchar(50) NOT NULL,
  `crcpt_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `crcpt_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_crcpt`
--

LOCK TABLES `tmpb_crcpt` WRITE;
/*!40000 ALTER TABLE `tmpb_crcpt` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_crcpt` VALUES
('e8129174-b1f9-4bbb-be83-793b421250df','73e3b55a-4d23-4228-b4d4-c752011ac41f','f241e3b7-3f83-42f4-ac10-af8def91799a','38b496e9-6652-4324-8331-ba0ecb0cfeae',55.000000,100.000000,5500.000000,0.000000,0.000000,5.000000,275.000000,55.000000,5775.000000,'','{}',0.000000,0.000000,100.000000,'ee7a4b40-451b-4022-b930-061cd7b39bfa',1,'user1','2026-02-05 09:31:12','user1','2026-02-05 09:31:12',1),
('e9c8cc55-42b3-4e66-b83a-dcc41ce02e77','73e3b55a-4d23-4228-b4d4-c752011ac41f','9a04c7bb-e9d8-4adf-8eff-1fe92e43c971','fa1b188a-c075-4b90-bbea-37e3733f50bb',750.000000,100.000000,75000.000000,0.000000,0.000000,5.000000,3750.000000,750.000000,78750.000000,'','{}',0.000000,10.000000,90.000000,'22be751a-e91e-4b0a-994f-a686e1383ecb',1,'user1','2026-02-05 09:31:12','user1','2026-02-05 09:49:47',1);
/*!40000 ALTER TABLE `tmpb_crcpt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_expns`
--

DROP TABLE IF EXISTS `tmpb_expns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_expns` (
  `id` varchar(50) NOT NULL,
  `expns_users` varchar(50) NOT NULL,
  `expns_bsins` varchar(50) NOT NULL,
  `expns_cntct` varchar(50) NOT NULL,
  `expns_refid` varchar(50) NOT NULL,
  `expns_refno` varchar(50) NOT NULL,
  `expns_srcnm` varchar(50) NOT NULL,
  `expns_trdat` date NOT NULL DEFAULT current_timestamp(),
  `expns_inexc` tinyint(1) NOT NULL DEFAULT 1,
  `expns_notes` varchar(100) DEFAULT NULL,
  `expns_xpamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `expns_actve` tinyint(1) NOT NULL DEFAULT 1,
  `expns_crusr` varchar(50) NOT NULL,
  `expns_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `expns_upusr` varchar(50) NOT NULL,
  `expns_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expns_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_expns`
--

LOCK TABLES `tmpb_expns` WRITE;
/*!40000 ALTER TABLE `tmpb_expns` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmpb_expns` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_mbkng`
--

DROP TABLE IF EXISTS `tmpb_mbkng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_mbkng` (
  `id` varchar(50) NOT NULL,
  `mbkng_users` varchar(50) NOT NULL,
  `mbkng_bsins` varchar(50) NOT NULL,
  `mbkng_cntct` varchar(50) NOT NULL,
  `mbkng_trnno` varchar(50) NOT NULL,
  `mbkng_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mbkng_refno` varchar(50) DEFAULT NULL,
  `mbkng_trnte` varchar(100) DEFAULT NULL,
  `mbkng_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_cnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mbkng_crusr` varchar(50) NOT NULL,
  `mbkng_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mbkng_upusr` varchar(50) NOT NULL,
  `mbkng_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mbkng_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_mbkng`
--

LOCK TABLES `tmpb_mbkng` WRITE;
/*!40000 ALTER TABLE `tmpb_mbkng` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_mbkng` VALUES
('c4714648-8827-4d9a-b665-5bad97ed5e35','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PB-050226-00001','2026-02-05 00:00:00','','',80500.000000,0.000000,4025.000000,1,0.000000,0.000000,0.000000,84525.000000,84525.000000,84525.000000,0.000000,0.000000,1,1,0,0,0,1,'user1','2026-02-05 09:30:47','user1','2026-02-05 09:30:47',1);
/*!40000 ALTER TABLE `tmpb_mbkng` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_minvc`
--

DROP TABLE IF EXISTS `tmpb_minvc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_minvc` (
  `id` varchar(50) NOT NULL,
  `minvc_users` varchar(50) NOT NULL,
  `minvc_bsins` varchar(50) NOT NULL,
  `minvc_cntct` varchar(50) NOT NULL,
  `minvc_trnno` varchar(50) NOT NULL,
  `minvc_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `minvc_refno` varchar(50) DEFAULT NULL,
  `minvc_trnte` varchar(100) DEFAULT NULL,
  `minvc_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_rtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_actve` tinyint(1) NOT NULL DEFAULT 1,
  `minvc_crusr` varchar(50) NOT NULL,
  `minvc_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `minvc_upusr` varchar(50) NOT NULL,
  `minvc_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `minvc_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_minvc`
--

LOCK TABLES `tmpb_minvc` WRITE;
/*!40000 ALTER TABLE `tmpb_minvc` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_minvc` VALUES
('0f97e570-b98a-4a78-8ca8-51f488ecefd1','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PI-050226-00001','2026-02-05 00:00:00','','',30000.000000,0.000000,1500.000000,1,0.000000,0.000000,0.000000,31500.000000,31500.000000,31500.000000,0.000000,0.000000,1,1,0,0,0,1,'user1','2026-02-05 09:32:53','user1','2026-02-05 09:32:53',1);
/*!40000 ALTER TABLE `tmpb_minvc` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_mrcpt`
--

DROP TABLE IF EXISTS `tmpb_mrcpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_mrcpt` (
  `id` varchar(50) NOT NULL,
  `mrcpt_users` varchar(50) NOT NULL,
  `mrcpt_bsins` varchar(50) NOT NULL,
  `mrcpt_cntct` varchar(50) NOT NULL,
  `mrcpt_trnno` varchar(50) NOT NULL,
  `mrcpt_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mrcpt_refno` varchar(50) DEFAULT NULL,
  `mrcpt_trnte` varchar(100) DEFAULT NULL,
  `mrcpt_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_rtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mrcpt_crusr` varchar(50) NOT NULL,
  `mrcpt_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mrcpt_upusr` varchar(50) NOT NULL,
  `mrcpt_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mrcpt_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_mrcpt`
--

LOCK TABLES `tmpb_mrcpt` WRITE;
/*!40000 ALTER TABLE `tmpb_mrcpt` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_mrcpt` VALUES
('73e3b55a-4d23-4228-b4d4-c752011ac41f','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PR-050226-00001','2026-02-05 00:00:00','','',80500.000000,0.000000,4025.000000,1,0.000000,0.000000,0.000000,84525.000000,84525.000000,84525.000000,0.000000,0.000000,1,1,0,0,0,1,'user1','2026-02-05 09:31:12','user1','2026-02-05 09:31:12',1);
/*!40000 ALTER TABLE `tmpb_mrcpt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_bsins`
--

DROP TABLE IF EXISTS `tmsb_bsins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_bsins` (
  `id` varchar(50) NOT NULL,
  `bsins_users` varchar(255) NOT NULL,
  `bsins_bname` varchar(255) NOT NULL,
  `bsins_addrs` varchar(255) DEFAULT NULL,
  `bsins_email` varchar(255) DEFAULT NULL,
  `bsins_cntct` varchar(255) DEFAULT NULL,
  `bsins_image` varchar(255) DEFAULT NULL,
  `bsins_binno` varchar(255) DEFAULT NULL,
  `bsins_btags` varchar(255) DEFAULT NULL,
  `bsins_cntry` varchar(50) DEFAULT NULL,
  `bsins_bstyp` varchar(50) DEFAULT NULL,
  `bsins_tstrn` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_prtrn` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_sltrn` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_stdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bsins_pbviw` tinyint(1) NOT NULL DEFAULT 0,
  `bsins_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_crusr` varchar(50) NOT NULL,
  `bsins_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bsins_upusr` varchar(50) NOT NULL,
  `bsins_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bsins_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_bsins_users_bsins_bname` (`bsins_users`,`bsins_bname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_bsins`
--

LOCK TABLES `tmsb_bsins` WRITE;
/*!40000 ALTER TABLE `tmsb_bsins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_bsins` VALUES
('business1','user1','Green Mart – Uttara','Sector 10, Uttara, Dhaka','admin@sgd.com','01722688266',NULL,'GT-9872-6871-5555','Retail','Bangladesh','Store',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:38',6),
('business2','user1','White Mart – Dhanmondi','Road 27, Dhanmondi, Dhaka','admin@sgd.com','01722688266',NULL,'CT2025-0978-22364','Retail','Bangladesh','Store',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:40',3),
('business3','user1','Red Mart - Badda','Uttar Badda, Dhaka','admin@sgd.com','01722688266',NULL,'CT2025-0978-22364','Retail','Bangladesh','Store',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:42',3),
('business4','user1','Central Distribution Warehouse','Uttar Badda, Dhaka','admin@sgd.com','01722688266',NULL,'CT2025-0978-22364','Retail','Bangladesh','Warehouse',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:43',7);
/*!40000 ALTER TABLE `tmsb_bsins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_crgrn`
--

DROP TABLE IF EXISTS `tmsb_crgrn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_crgrn` (
  `id` varchar(50) NOT NULL,
  `crgrn_users` varchar(50) NOT NULL,
  `crgrn_bsins` varchar(50) NOT NULL,
  `crgrn_tblnm` varchar(50) NOT NULL,
  `crgrn_tbltx` varchar(50) DEFAULT NULL,
  `crgrn_refno` varchar(50) DEFAULT NULL,
  `crgrn_dbgrn` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `crgrn_crgrn` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `crgrn_isdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crgrn_xpdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crgrn_actve` tinyint(1) NOT NULL DEFAULT 1,
  `crgrn_crusr` varchar(50) NOT NULL,
  `crgrn_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crgrn_upusr` varchar(50) NOT NULL,
  `crgrn_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `crgrn_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_crgrn`
--

LOCK TABLES `tmsb_crgrn` WRITE;
/*!40000 ALTER TABLE `tmsb_crgrn` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_crgrn` VALUES
('e0bdba06-a4d9-4010-90dc-ab4d433cb413','u1','b1','tmsb_crgrn','Registration','My Shop BD',0.000000,1000.000000,'2026-01-31 08:03:14','2026-01-31 08:03:14',1,'u1','2026-01-31 08:03:14','u1','2026-01-31 08:04:27',1);
/*!40000 ALTER TABLE `tmsb_crgrn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_mdule`
--

DROP TABLE IF EXISTS `tmsb_mdule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_mdule` (
  `id` varchar(50) NOT NULL,
  `mdule_mname` varchar(50) NOT NULL,
  `mdule_pname` varchar(50) NOT NULL,
  `mdule_micon` varchar(50) DEFAULT NULL,
  `mdule_color` varchar(50) DEFAULT NULL,
  `mdule_notes` varchar(50) DEFAULT NULL,
  `mdule_odrby` int(11) NOT NULL DEFAULT 0,
  `mdule_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mdule_crusr` varchar(50) NOT NULL,
  `mdule_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mdule_upusr` varchar(50) NOT NULL,
  `mdule_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mdule_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_mdule_mname` (`mdule_mname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_mdule`
--

LOCK TABLES `tmsb_mdule` WRITE;
/*!40000 ALTER TABLE `tmsb_mdule` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_mdule` VALUES
('accounts','Accounts','basic','pi-wallet','bg-teal-500',NULL,1,1,'user1','2026-02-02 09:53:24','user1','2026-02-03 06:16:02',1),
('crm','CRM','basic','pi-phone','bg-purple-500',NULL,2,1,'user1','2026-02-02 09:53:24','user1','2026-02-03 06:16:05',1),
('hrms','HRMS','basic','pi-address-book','bg-green-500',NULL,3,1,'user1','2026-02-02 09:53:24','user1','2026-02-03 08:23:33',1),
('setup','Setup','basic','pi-cog','bg-gray-500',NULL,5,1,'user1','2026-02-02 09:53:24','user1','2026-02-03 08:23:48',1),
('shop','Shop','basic','pi-home','bg-orange-500',NULL,4,1,'user1','2026-02-02 09:53:24','user1','2026-02-03 06:16:17',1),
('support','Support','basic','pi-question-circle','bg-blue-500',NULL,6,1,'user1','2026-02-02 09:53:24','user1','2026-02-03 06:18:44',1);
/*!40000 ALTER TABLE `tmsb_mdule` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_menus`
--

DROP TABLE IF EXISTS `tmsb_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_menus` (
  `id` varchar(50) NOT NULL,
  `menus_mdule` varchar(50) NOT NULL,
  `menus_gname` varchar(50) NOT NULL,
  `menus_gicon` varchar(50) NOT NULL,
  `menus_mname` varchar(50) NOT NULL,
  `menus_pname` varchar(50) DEFAULT NULL,
  `menus_micon` varchar(50) DEFAULT NULL,
  `menus_mlink` varchar(255) DEFAULT NULL,
  `menus_notes` varchar(255) DEFAULT NULL,
  `menus_odrby` int(11) NOT NULL DEFAULT 0,
  `menus_actve` tinyint(1) NOT NULL DEFAULT 1,
  `menus_crusr` varchar(50) NOT NULL,
  `menus_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `menus_upusr` varchar(50) NOT NULL,
  `menus_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `menus_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_menus`
--

LOCK TABLES `tmsb_menus` WRITE;
/*!40000 ALTER TABLE `tmsb_menus` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_menus` VALUES
('accounts-accounts','accounts','Accounts','pi pi-money-bill','Accounts','basic','pi pi-money-bill','/home/accounts/accounts',NULL,711,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:32:01',1),
('accounts-expenses','accounts','Transactions','pi pi-folder-plus','Expenses','basic','pi pi-money-bill','/home/accounts/expenses',NULL,703,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:32:21',1),
('accounts-heads','accounts','Accounts','pi pi-money-bill','Heads','basic','pi pi-objects-column','/home/accounts/heads',NULL,710,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:31:49',1),
('accounts-ledger','accounts','Transactions','pi pi-folder-plus','Ledger','basic','pi pi-arrow-right-arrow-left','/home/accounts/ledger',NULL,700,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:32:06',1),
('accounts-payables','accounts','Transactions','pi pi-folder-plus','Payables','basic','pi pi-money-bill','/home/accounts/payables',NULL,701,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:32:13',1),
('accounts-receivables','accounts','Transactions','pi pi-folder-plus','Receivables','basic','pi pi-money-bill','/home/accounts/receivables',NULL,702,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:32:18',1),
('crm-contacts','crm','CRM','pi pi-address-book','Contacts','basic','pi pi-id-card','/home/crm/contact',NULL,1,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:11:05',1),
('crm-field-route','crm','CRM','pi pi-address-book','Routes','basic','pi pi-directions','/home/crm/field-route',NULL,1,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:11:05',1),
('hrms-employees','hrms','Employee','pi pi-users','Employee','basic','pi pi-user','/home/hrms/employees',NULL,1,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:24:23',1),
('inventory-category','shop','Inventory','pi pi-box','Category','basic','pi pi-list-check','/home/inventory/category',NULL,321,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:30:30',1),
('inventory-product','shop','Inventory','pi pi-box','Product','basic','pi pi-box','/home/inventory/products',NULL,300,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:29:53',1),
('inventory-stock-transfer','shop','Inventory','pi pi-box','Stock Transfer','basic','pi pi-arrow-right-arrow-left','/home/inventory/itransfer',NULL,302,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:30:05',1),
('inventory-tracking-stock','shop','Inventory','pi pi-box','Tracking Stock','basic','pi pi-file','/home/inventory/stockreports',NULL,301,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:30:01',1),
('inventory-unit','shop','Inventory','pi pi-box','Unit','basic','pi pi-tags','/home/inventory/unit',NULL,320,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:30:12',1),
('purchase-booking','shop','Purchase','pi pi-shopping-cart','Booking','basic','pi pi-check-square','/home/purchase/pbooking',NULL,200,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:29:03',1),
('purchase-invoice','shop','Purchase','pi pi-shopping-cart','Invoice','basic','pi pi-file-edit','/home/purchase/pinvoice',NULL,202,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:29:21',1),
('purchase-receipt','shop','Purchase','pi pi-shopping-cart','Receipt','basic','pi pi-receipt','/home/purchase/preceipt',NULL,201,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:29:16',1),
('sales-invoice','shop','Sales','pi pi-shopping-bag','Invoice','basic','pi pi-file-edit','/home/sales/sinvoice',NULL,100,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:28:56',1),
('setup-business','setup','Business','pi pi-cog','Business','basic','pi pi-shop','/home/setup/business',NULL,1,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:11:05',1),
('setup-database','setup','Database','pi pi-database','Backup','basic','pi pi-save','/home/setup/database',NULL,1,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:27:53',1),
('setup-users','setup','Business','pi pi-cog','Users','basic','pi pi-users','/home/setup/users',NULL,1,1,'user1','2026-02-02 09:58:00','user1','2026-02-03 08:11:05',1);
/*!40000 ALTER TABLE `tmsb_menus` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_ucnfg`
--

DROP TABLE IF EXISTS `tmsb_ucnfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_ucnfg` (
  `id` varchar(50) NOT NULL,
  `ucnfg_users` varchar(50) NOT NULL,
  `ucnfg_bsins` varchar(50) NOT NULL,
  `ucnfg_cname` varchar(50) DEFAULT NULL,
  `ucnfg_gname` varchar(50) DEFAULT NULL,
  `ucnfg_label` varchar(50) DEFAULT NULL,
  `ucnfg_value` varchar(50) DEFAULT NULL,
  `ucnfg_notes` varchar(50) DEFAULT NULL,
  `ucnfg_actve` tinyint(1) NOT NULL DEFAULT 1,
  `ucnfg_crusr` varchar(50) NOT NULL,
  `ucnfg_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ucnfg_upusr` varchar(50) NOT NULL,
  `ucnfg_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ucnfg_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_ucnfg`
--

LOCK TABLES `tmsb_ucnfg` WRITE;
/*!40000 ALTER TABLE `tmsb_ucnfg` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_ucnfg` VALUES
('c1','user1','business1','Purchase','Booking','mbkng_vatpy','1','Including VAT',1,'user1','2026-02-02 10:45:00','user1','2026-02-02 11:09:34',1),
('c2','user1','business1','Purchase','Booking','mbkng_ispst','1','Default Posted Checked',1,'user1','2026-02-02 10:45:00','user1','2026-02-02 11:07:49',1),
('c3','user1','business1','Purchase','Receipt','mrcpt_vatpy','1','Including VAT',1,'user1','2026-02-02 10:45:00','user1','2026-02-02 11:09:37',1),
('c4','user1','business1','Sales','Invoice','minvc_vatpy','1','Including VAT',1,'user1','2026-02-02 10:45:00','user1','2026-02-02 11:09:37',1),
('c5','user1','business1','Sales','Invoice','minvc_ispst','1','Default Posted Checked',1,'user1','2026-02-02 10:45:00','user1','2026-02-02 11:07:49',1);
/*!40000 ALTER TABLE `tmsb_ucnfg` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_users`
--

DROP TABLE IF EXISTS `tmsb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_users` (
  `id` varchar(50) NOT NULL,
  `users_email` varchar(50) NOT NULL,
  `users_pswrd` varchar(50) NOT NULL,
  `users_recky` varchar(50) NOT NULL,
  `users_oname` varchar(255) NOT NULL,
  `users_cntct` varchar(50) DEFAULT NULL,
  `users_bsins` varchar(50) DEFAULT NULL,
  `users_drole` varchar(50) DEFAULT NULL,
  `users_users` varchar(50) DEFAULT NULL,
  `users_stats` int(11) NOT NULL DEFAULT 0,
  `users_regno` varchar(50) DEFAULT NULL,
  `users_regdt` datetime NOT NULL DEFAULT current_timestamp(),
  `users_ltokn` varchar(50) DEFAULT NULL,
  `users_lstgn` datetime NOT NULL DEFAULT current_timestamp(),
  `users_lstpd` datetime NOT NULL DEFAULT current_timestamp(),
  `users_wctxt` varchar(100) DEFAULT NULL,
  `users_notes` varchar(100) DEFAULT NULL,
  `users_nofcr` decimal(16,2) NOT NULL DEFAULT 0.00,
  `users_isrgs` tinyint(1) NOT NULL DEFAULT 1,
  `users_actve` tinyint(1) NOT NULL DEFAULT 1,
  `users_crusr` varchar(50) NOT NULL,
  `users_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `users_upusr` varchar(50) NOT NULL,
  `users_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `users_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`users_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_users`
--

LOCK TABLES `tmsb_users` WRITE;
/*!40000 ALTER TABLE `tmsb_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_users` VALUES
('user1','admin@sgd.com','password','recover','Admin','01722688266','business1','Admin','user1',0,'Standard','2026-01-31 08:03:14',NULL,'2026-01-31 08:03:14','2026-01-31 09:43:39','Welcome Note','User Note',1000.00,1,1,'u1','2026-01-31 08:03:14','user1','2026-01-31 09:43:48',5),
('user2','user@sgd.com','password','recover','Common User','01722688266','business1','Admin','user1',0,'Standard','2026-01-31 09:29:44',NULL,'2026-01-31 09:29:44','2026-01-31 09:29:44','Welcome Note','User Note',0.00,0,1,'user1','2026-01-31 09:29:44','user1','2026-01-31 09:35:42',1);
/*!40000 ALTER TABLE `tmsb_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_bacts`
--

DROP TABLE IF EXISTS `tmtb_bacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_bacts` (
  `id` varchar(50) NOT NULL,
  `bacts_users` varchar(50) NOT NULL,
  `bacts_bankn` varchar(100) NOT NULL,
  `bacts_brnch` varchar(100) DEFAULT NULL,
  `bacts_routn` varchar(50) DEFAULT NULL,
  `bacts_acnam` varchar(100) DEFAULT NULL,
  `bacts_acnum` varchar(100) DEFAULT NULL,
  `bacts_notes` varchar(300) DEFAULT NULL,
  `bacts_opdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bacts_crbln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `bacts_isdef` tinyint(1) NOT NULL DEFAULT 0,
  `bacts_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bacts_crusr` varchar(50) NOT NULL,
  `bacts_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bacts_upusr` varchar(50) NOT NULL,
  `bacts_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bacts_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_bacts`
--

LOCK TABLES `tmtb_bacts` WRITE;
/*!40000 ALTER TABLE `tmtb_bacts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_bacts` VALUES
('14bc4749-859b-46aa-aa67-29b926f88083','admin-id','Brac Bank PLC','Gulshan 2','123456','Sand Grain Digital','15000003454545','Deposit account','2026-01-09 00:00:00',5000.000000,0,0,'admin-id','2026-01-09 17:37:49','admin-id','2026-01-17 06:40:27',3),
('c306af10-f4c2-4ee8-8593-85de14c35b76','admin-id','Cash Account','Cash Account','0','Cash Account','123456','Cash Account','2026-01-09 00:00:00',23465.000000,1,1,'4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-09 12:06:49','4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-17 06:43:49',1);
/*!40000 ALTER TABLE `tmtb_bacts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_ledgr`
--

DROP TABLE IF EXISTS `tmtb_ledgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_ledgr` (
  `id` varchar(50) NOT NULL,
  `ledgr_users` varchar(50) NOT NULL,
  `ledgr_bsins` varchar(50) NOT NULL,
  `ledgr_trhed` varchar(50) NOT NULL,
  `ledgr_cntct` varchar(50) NOT NULL,
  `ledgr_bacts` varchar(50) NOT NULL,
  `ledgr_pymod` varchar(50) NOT NULL,
  `ledgr_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ledgr_refno` varchar(50) NOT NULL,
  `ledgr_notes` varchar(100) DEFAULT NULL,
  `ledgr_dbamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `ledgr_cramt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `ledgr_crusr` varchar(50) NOT NULL,
  `ledgr_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ledgr_upusr` varchar(50) NOT NULL,
  `ledgr_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ledgr_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_ledgr`
--

LOCK TABLES `tmtb_ledgr` WRITE;
/*!40000 ALTER TABLE `tmtb_ledgr` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_ledgr` VALUES
('322544db-ccf2-4326-94ea-c92325654f99','user1','business1','Z901','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-10 00:00:00','rent-5656','',1500.000000,0.000000,'user1','2026-01-10 08:17:42','user1','2026-02-03 08:47:59',1),
('3ddc69c4-c35d-4131-bf89-6af78de59c4f','user1','business1','Z701','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-17 00:00:00','#Cash Excess','',0.000000,365.000000,'user1','2026-01-17 06:39:45','user1','2026-02-03 08:47:59',1),
('57635f84-7cae-4a10-8927-cd34447800de','user1','business1','Z904','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-10 00:00:00','nov','',500.000000,0.000000,'user1','2026-01-10 08:19:11','user1','2026-02-03 08:47:59',1),
('5bb72d2a-7ef7-42c3-a12d-17ea7e874344','user1','business1','Z702','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-10 00:00:00','cash investment','',0.000000,25000.000000,'user1','2026-01-10 08:16:12','user1','2026-02-03 08:47:59',1),
('665b8fac-564b-470a-a922-4c484bfe1474','user1','business1','Z602','internal','14bc4749-859b-46aa-aa67-29b926f88083','Bank','2026-01-10 00:00:00','transfer','',0.000000,5000.000000,'user1','2026-01-10 08:16:47','user1','2026-02-03 08:47:59',1),
('6bf954fd-fea2-4898-9821-48874ac98e4d','user1','business1','Z903','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','MFS','2026-01-10 00:00:00','nov','',500.000000,0.000000,'user1','2026-01-10 08:18:22','user1','2026-02-03 08:47:59',1),
('8cddba78-957f-4745-b9fd-e5d2381222f0','user1','business1','Z1002','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-17 00:00:00','scap sales','',0.000000,5600.000000,'user1','2026-01-17 06:43:49','user1','2026-02-03 08:47:59',1),
('efaade64-7c50-4fe7-b1d3-f033622e800d','user1','business1','Z601','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Bank','2026-01-10 00:00:00','transfer','',5000.000000,0.000000,'user1','2026-01-10 08:16:47','user1','2026-02-03 08:47:59',1);
/*!40000 ALTER TABLE `tmtb_ledgr` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_paybl`
--

DROP TABLE IF EXISTS `tmtb_paybl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_paybl` (
  `id` varchar(50) NOT NULL,
  `paybl_users` varchar(50) NOT NULL,
  `paybl_bsins` varchar(50) NOT NULL,
  `paybl_cntct` varchar(50) NOT NULL,
  `paybl_pymod` varchar(50) NOT NULL,
  `paybl_refid` varchar(50) NOT NULL,
  `paybl_refno` varchar(50) NOT NULL,
  `paybl_srcnm` varchar(50) NOT NULL,
  `paybl_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `paybl_descr` varchar(100) DEFAULT NULL,
  `paybl_notes` varchar(50) NOT NULL,
  `paybl_dbamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `paybl_cramt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `paybl_crusr` varchar(50) NOT NULL,
  `paybl_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `paybl_upusr` varchar(50) NOT NULL,
  `paybl_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `paybl_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_paybl`
--

LOCK TABLES `tmtb_paybl` WRITE;
/*!40000 ALTER TABLE `tmtb_paybl` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_paybl` VALUES
('3151b1b7-1e69-4b00-be3d-b010aadf82b8','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Cash','c4714648-8827-4d9a-b665-5bad97ed5e35','PB-050226-00001','Purchase Booking','2026-02-05 00:00:00','','Payment',84525.000000,0.000000,'user1','2026-02-05 09:30:47','user1','2026-02-05 09:30:47',1),
('5eb3b0bf-fdb8-4695-8260-544323036690','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Payment','73e3b55a-4d23-4228-b4d4-c752011ac41f','PR-050226-00001','Purchase Receipt','2026-02-05 00:00:00','Supplier Payment','Payment',84525.000000,0.000000,'user1','2026-02-05 09:31:12','user1','2026-02-05 09:31:12',1),
('6f6c305f-e473-4f06-baca-a97ff68ed7f2','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','73e3b55a-4d23-4228-b4d4-c752011ac41f','PR-050226-00001','Purchase Receipt','2026-02-05 00:00:00','Supplier Goods','Products',0.000000,84525.000000,'user1','2026-02-05 09:31:12','user1','2026-02-05 09:31:12',1),
('9d31fd92-f37c-4169-b3e5-d31923b5d5dc','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Cash','0f97e570-b98a-4a78-8ca8-51f488ecefd1','PI-050226-00001','Purchase Invoice','2026-02-05 00:00:00','','Payment',31500.000000,0.000000,'user1','2026-02-05 09:32:53','user1','2026-02-05 09:32:53',1),
('a9ce4508-fcf7-43db-a23a-3fd80f963d53','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','c4714648-8827-4d9a-b665-5bad97ed5e35','PB-050226-00001','Purchase Booking','2026-02-05 00:00:00','Supplier Goods','Products',0.000000,84525.000000,'user1','2026-02-05 09:30:47','user1','2026-02-05 09:30:47',1),
('ad918aac-7b72-428e-94bf-21b73076df30','user1','business1','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','0f97e570-b98a-4a78-8ca8-51f488ecefd1','PI-050226-00001','Purchase Invoice','2026-02-05 00:00:00','Supplier Goods','Products',0.000000,31500.000000,'user1','2026-02-05 09:32:53','user1','2026-02-05 09:32:53',1);
/*!40000 ALTER TABLE `tmtb_paybl` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_rcvbl`
--

DROP TABLE IF EXISTS `tmtb_rcvbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_rcvbl` (
  `id` varchar(50) NOT NULL,
  `rcvbl_users` varchar(50) NOT NULL,
  `rcvbl_bsins` varchar(50) NOT NULL,
  `rcvbl_cntct` varchar(50) NOT NULL,
  `rcvbl_pymod` varchar(50) NOT NULL,
  `rcvbl_refid` varchar(50) NOT NULL,
  `rcvbl_refno` varchar(50) NOT NULL,
  `rcvbl_srcnm` varchar(50) NOT NULL,
  `rcvbl_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rcvbl_descr` varchar(100) DEFAULT NULL,
  `rcvbl_notes` varchar(50) NOT NULL,
  `rcvbl_dbamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rcvbl_cramt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rcvbl_crusr` varchar(50) NOT NULL,
  `rcvbl_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rcvbl_upusr` varchar(50) NOT NULL,
  `rcvbl_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rcvbl_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_rcvbl`
--

LOCK TABLES `tmtb_rcvbl` WRITE;
/*!40000 ALTER TABLE `tmtb_rcvbl` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_rcvbl` VALUES
('08ce334b-0db4-4d45-af67-383bf37020ab','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','Cash','cdb0a7ab-0a31-4d10-aeb7-b2a06a91e427','SI-050226-00001','Sales Booking','2026-02-05 00:00:00','','Payment',14753.000000,0.000000,'user1','2026-02-05 09:49:47','user1','2026-02-05 09:49:47',1),
('3b1ae9bf-a11b-403a-a834-18b9f4e488a6','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','Inventory','cdb0a7ab-0a31-4d10-aeb7-b2a06a91e427','SI-050226-00001','Sales Booking','2026-02-05 00:00:00','Supplier Goods','Products',0.000000,14752.500000,'user1','2026-02-05 09:49:47','user1','2026-02-05 09:49:47',1),
('9276c90e-34e0-4f54-a0ec-3606111e7b4e','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','Inventory','02113046-37f4-4167-aa6d-3aa09ef453e0','SI-050226-00002','Sales Invoice','2026-02-05 00:00:00','Customer Goods','Products',0.000000,4010.000000,'user1','2026-02-05 09:52:06','user1','2026-02-05 09:52:06',1),
('a5cd4ccb-0c67-4985-b64b-889f9df9281b','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','Cash','3c8eb29d-ceb8-481a-b62a-4bb15b57749a','SI-050226-00003','Sales Invoice','2026-02-05 00:00:00','advance payment','Payment',4000.000000,0.000000,'user1','2026-02-05 10:00:33','user1','2026-02-05 10:00:33',1),
('cb8657a0-ba72-434d-b720-7c850c9affd5','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','Cash','02113046-37f4-4167-aa6d-3aa09ef453e0','SI-050226-00002','Sales Invoice','2026-02-05 00:00:00','','Payment',4010.000000,0.000000,'user1','2026-02-05 09:52:06','user1','2026-02-05 09:52:06',1),
('de68c59b-f818-4ad3-8dd3-a445fac7d73d','user1','business1','11f1664d-5d03-4724-a4dd-57ad3e01ad1a','Inventory','3c8eb29d-ceb8-481a-b62a-4bb15b57749a','SI-050226-00003','Sales Invoice','2026-02-05 00:00:00','Customer Goods','Products',0.000000,4090.000000,'user1','2026-02-05 10:00:33','user1','2026-02-05 10:00:33',1);
/*!40000 ALTER TABLE `tmtb_rcvbl` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_rcvpy`
--

DROP TABLE IF EXISTS `tmtb_rcvpy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_rcvpy` (
  `id` varchar(50) NOT NULL,
  `rcvpy_users` varchar(50) NOT NULL,
  `rcvpy_bsins` varchar(50) NOT NULL,
  `rcvpy_cntct` varchar(50) NOT NULL,
  `rcvpy_pymod` varchar(50) NOT NULL,
  `rcvpy_refid` varchar(50) NOT NULL,
  `rcvpy_refno` varchar(50) NOT NULL,
  `rcvpy_srcnm` varchar(50) NOT NULL,
  `rcvpy_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rcvpy_notes` varchar(100) DEFAULT NULL,
  `rcvpy_pyamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rcvpy_crusr` varchar(50) NOT NULL,
  `rcvpy_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rcvpy_upusr` varchar(50) NOT NULL,
  `rcvpy_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rcvpy_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_rcvpy`
--

LOCK TABLES `tmtb_rcvpy` WRITE;
/*!40000 ALTER TABLE `tmtb_rcvpy` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmtb_rcvpy` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_trhed`
--

DROP TABLE IF EXISTS `tmtb_trhed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_trhed` (
  `id` varchar(50) NOT NULL,
  `trhed_users` varchar(50) NOT NULL,
  `trhed_hednm` varchar(100) NOT NULL,
  `trhed_grpnm` varchar(100) NOT NULL,
  `trhed_grtyp` varchar(100) NOT NULL,
  `trhed_cntyp` varchar(100) NOT NULL,
  `trhed_actve` tinyint(1) NOT NULL DEFAULT 1,
  `trhed_crusr` varchar(50) NOT NULL,
  `trhed_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `trhed_upusr` varchar(50) NOT NULL,
  `trhed_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trhed_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_trhed`
--

LOCK TABLES `tmtb_trhed` WRITE;
/*!40000 ALTER TABLE `tmtb_trhed` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_trhed` VALUES
('Z1001','user1','Asset Purchase (-)','Asset','Out','Internal',1,'user1','2026-01-10 08:06:31','user1','2026-02-03 07:45:56',1),
('Z1002','user1','Asset Sale (+)','Asset','In','Internal',1,'user1','2026-01-10 08:06:31','user1','2026-02-03 07:45:56',1),
('Z101','user1','Sales Booking (+)','Sales','In','Customer',1,'user1','2026-01-10 08:07:18','user1','2026-02-03 07:45:56',1),
('Z102','user1','Sales Invoice (+)','Sales','In','Customer',1,'user1','2026-01-10 08:07:18','user1','2026-02-03 07:45:56',1),
('Z103','user1','Sales Order (+)','Sales','In','Customer',1,'user1','2026-01-10 08:07:18','user1','2026-02-03 07:45:56',1),
('Z104','user1','Sales Return (-)','Sales','Out','Customer',1,'user1','2026-01-10 08:07:18','user1','2026-02-03 07:45:56',1),
('Z105','user1','Sales Expense (-)','Sales','Out','Internal',1,'user1','2026-01-10 08:07:18','user1','2026-02-03 07:45:56',1),
('Z1101','user1','VAT Payment (-)','VAT','Out','Internal',1,'user1','2026-01-10 08:06:25','user1','2026-02-03 07:45:56',1),
('Z1102','user1','VAT Collection (+)','VAT','In','Internal',1,'user1','2026-01-10 08:06:25','user1','2026-02-03 07:45:56',1),
('Z1201','user1','Tax Payment (-)','Tax','Out','Internal',1,'user1','2026-01-10 08:06:18','user1','2026-02-03 07:45:56',1),
('Z1202','user1','Tax Receipt (+)','Tax','In','Internal',1,'user1','2026-01-10 08:06:18','user1','2026-02-03 07:45:56',1),
('Z1301','user1','Salary Payment (-)','HR','Out','Internal',1,'user1','2026-01-10 08:06:09','user1','2026-02-03 07:45:56',1),
('Z1302','user1','Salary Advance Payment (-)','HR','Out','Internal',1,'user1','2026-01-10 08:06:09','user1','2026-02-03 07:45:56',1),
('Z1303','user1','Salary Deduction (+)','HR','In','Internal',1,'user1','2026-01-10 08:06:09','user1','2026-02-03 07:45:56',1),
('Z1304','user1','Salary Advance Deduction (+)','HR','In','Internal',1,'user1','2026-01-10 08:06:09','user1','2026-02-03 07:45:56',1),
('Z201','user1','Purchase Booking (-)','Purchase','Out','Supplier',1,'user1','2026-01-10 08:07:11','user1','2026-02-03 07:45:56',1),
('Z202','user1','Purchase Invoice (-)','Purchase','Out','Supplier',1,'user1','2026-01-10 08:07:11','user1','2026-02-03 07:45:56',1),
('Z203','user1','Purchase Order (-)','Purchase','Out','Supplier',1,'user1','2026-01-10 08:07:11','user1','2026-02-03 07:45:56',1),
('Z204','user1','Purchase Return (+)','Purchase','In','Supplier',1,'user1','2026-01-10 08:07:11','user1','2026-02-03 07:45:56',1),
('Z205','user1','Purchase Expense (-)','Purchase','Out','Internal',1,'user1','2026-01-10 08:07:11','user1','2026-02-03 07:45:56',1),
('Z501','user1','Stock Out (-)','Inventory','Out','Internal',1,'user1','2026-01-10 08:07:05','user1','2026-02-03 07:45:56',1),
('Z502','user1','Stock In (+)','Inventory','In','Internal',1,'user1','2026-01-10 08:07:05','user1','2026-02-03 07:45:56',1),
('Z601','user1','Transfer Out (-)','Transfer','Out','Internal',1,'user1','2026-01-10 08:06:58','user1','2026-02-03 07:45:56',1),
('Z602','user1','Transfer In (+)','Transfer','In','Internal',1,'user1','2026-01-10 08:06:58','user1','2026-02-03 07:45:56',1),
('Z701','user1','Gain (+)','Income','In','Internal',1,'user1','2026-01-10 08:06:52','user1','2026-02-03 07:45:56',1),
('Z702','user1','Investment (+)','Income','In','Internal',1,'user1','2026-01-10 08:06:52','user1','2026-02-03 07:45:56',1),
('Z703','user1','Bank Profit (+)','Income','In','Internal',1,'user1','2026-01-10 08:06:52','user1','2026-02-03 07:45:56',1),
('Z704','user1','Bank Loan Received (+)','Income','In','Internal',1,'user1','2026-01-10 08:06:52','user1','2026-02-03 07:45:56',1),
('Z705','user1','Other Income (+)','Income','In','Internal',1,'user1','2026-01-10 08:06:52','user1','2026-02-03 07:45:56',1),
('Z801','user1','Loss (-)','Expenditure','Out','Internal',1,'user1','2026-01-10 08:06:45','user1','2026-02-03 07:45:56',1),
('Z802','user1','Withdrawal (-)','Expenditure','Out','Internal',1,'user1','2026-01-10 08:06:45','user1','2026-02-03 07:45:56',1),
('Z803','user1','Bank Charges (-)','Expenditure','Out','Internal',1,'user1','2026-01-10 08:06:45','user1','2026-02-03 07:45:56',1),
('Z804','user1','Bank Loan Payment (-)','Expenditure','Out','Internal',1,'user1','2026-01-10 08:06:45','user1','2026-02-03 07:45:56',1),
('Z805','user1','Other Cost (-)','Expenditure','Out','Internal',1,'user1','2026-01-10 08:06:45','user1','2026-02-03 07:45:56',1),
('Z901','user1','Rent (-)','Expense','Out','Internal',1,'user1','2026-01-10 08:06:39','user1','2026-02-03 07:45:56',1),
('Z902','user1','Rent Advance (-)','Expense','Out','Internal',1,'user1','2026-01-10 08:06:39','user1','2026-02-03 07:45:56',1),
('Z903','user1','Electricity Bill (-)','Expense','Out','Internal',1,'user1','2026-01-10 08:06:39','user1','2026-02-03 07:45:56',1),
('Z904','user1','Internet Bill (-)','Expense','Out','Internal',1,'user1','2026-01-10 08:06:39','user1','2026-02-03 07:45:56',1),
('Z905','user1','Transport Bill (-)','Expense','Out','Internal',1,'user1','2026-01-10 08:06:39','user1','2026-02-03 07:45:56',1);
/*!40000 ALTER TABLE `tmtb_trhed` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmub_notes`
--

DROP TABLE IF EXISTS `tmub_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmub_notes` (
  `id` varchar(50) NOT NULL,
  `notes_users` varchar(50) NOT NULL,
  `notes_title` varchar(100) NOT NULL,
  `notes_descr` varchar(500) DEFAULT NULL,
  `notes_dudat` datetime NOT NULL DEFAULT current_timestamp(),
  `notes_stat` varchar(50) DEFAULT 'In Progress',
  `notes_actve` tinyint(1) NOT NULL DEFAULT 1,
  `notes_crusr` varchar(50) NOT NULL,
  `notes_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `notes_upusr` varchar(50) NOT NULL,
  `notes_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `notes_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmub_notes`
--

LOCK TABLES `tmub_notes` WRITE;
/*!40000 ALTER TABLE `tmub_notes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmub_notes` VALUES
('6e9a94bf-a9ec-4d3f-9ed1-e0da18c1c0f9','admin-id','Development in Progress','Development in Progress','2026-01-15 01:56:00','Scheduled',0,'admin-id','2026-01-14 07:58:44','admin-id','2026-01-28 06:32:17',6);
/*!40000 ALTER TABLE `tmub_notes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmub_tickt`
--

DROP TABLE IF EXISTS `tmub_tickt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmub_tickt` (
  `id` varchar(50) NOT NULL,
  `tickt_users` varchar(50) NOT NULL,
  `tickt_types` varchar(50) NOT NULL,
  `tickt_cmnte` varchar(300) NOT NULL,
  `tickt_cmdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tickt_rsnte` varchar(300) DEFAULT NULL,
  `tickt_rspnt` int(11) NOT NULL DEFAULT 0,
  `tickt_cmsts` varchar(50) DEFAULT 'Opened',
  `tickt_rsdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tickt_actve` tinyint(1) NOT NULL DEFAULT 1,
  `tickt_crusr` varchar(50) NOT NULL,
  `tickt_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tickt_upusr` varchar(50) NOT NULL,
  `tickt_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tickt_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmub_tickt`
--

LOCK TABLES `tmub_tickt` WRITE;
/*!40000 ALTER TABLE `tmub_tickt` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmub_tickt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'shopdb'
--

--
-- Dumping routines for database 'shopdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-02-08  7:54:11
