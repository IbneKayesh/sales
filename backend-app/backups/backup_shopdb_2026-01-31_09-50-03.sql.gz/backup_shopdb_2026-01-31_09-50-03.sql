/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.1.2-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: shopdb
-- ------------------------------------------------------
-- Server version	12.1.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `tmcb_cntct`
--

DROP TABLE IF EXISTS `tmcb_cntct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_cntct` (
  `id` varchar(50) NOT NULL,
  `cntct_users` varchar(50) NOT NULL,
  `cntct_bsins` varchar(50) NOT NULL,
  `cntct_ctype` varchar(50) NOT NULL,
  `cntct_sorce` varchar(50) NOT NULL,
  `cntct_cntnm` varchar(200) NOT NULL,
  `cntct_cntps` varchar(50) DEFAULT NULL,
  `cntct_cntno` varchar(50) DEFAULT NULL,
  `cntct_email` varchar(50) DEFAULT NULL,
  `cntct_tinno` varchar(50) NOT NULL,
  `cntct_trade` varchar(50) NOT NULL,
  `cntct_ofadr` varchar(300) DEFAULT NULL,
  `cntct_fcadr` varchar(300) DEFAULT NULL,
  `cntct_tarea` varchar(50) NOT NULL,
  `cntct_dzone` varchar(50) NOT NULL,
  `cntct_cntry` varchar(50) DEFAULT NULL,
  `cntct_cntad` varchar(50) DEFAULT NULL,
  `cntct_dspct` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_crlmt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_pybln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_adbln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_crbln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `cntct_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cntct_crusr` varchar(50) NOT NULL,
  `cntct_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cntct_upusr` varchar(50) NOT NULL,
  `cntct_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cntct_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_cntct`
--

LOCK TABLES `tmcb_cntct` WRITE;
/*!40000 ALTER TABLE `tmcb_cntct` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmcb_cntct` VALUES
('08eb3501-fcd0-4d99-84c3-ce5309bfe613','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Supplier','Local','Bengal Fresh Foods','Nusrat Jahan','01822-000002','email@sgd.com','TIN-123456','TRADE-123456','Chittagong Wholesale Market','Chittagong Wholesale Market','sirajganj-sadar','sirajganj','Bangladesh','0',10.000000,20000.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-14 09:17:52','admin-id','2026-01-25 05:14:59',6),
('11f1664d-5d03-4724-a4dd-57ad3e01ad1a','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Customer','Local','Al Noor Store','Javed Hasan','01623-100104','email@sgd.com','TIN-123456','TRADE-123456','Sylhet Zindabazar','Sylhet Zindabazar','bogra-sadar','bogra','Bangladesh','0',10.000000,0.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-18 11:24:23','admin-id','2026-01-25 05:13:00',3),
('267bb3aa-9177-43d2-8d8b-e0137578cf98','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Supplier','Local','Dhaka Agro Traders','Md. Kamal Hossain','01711-000001','email@email.com','','','Kawran Bazar, Dhaka','Kawran Bazar, Dhaka','araihazar','narayanganj','Bangladesh','0',0.000000,20000.000000,0.000000,0.000000,0.000000,1,'4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-09 12:02:10','admin-id','2026-01-25 05:36:49',4),
('41981c62-d7fc-4238-a8f1-8c70bd2c1e0e','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Customer','Local','Bismillah Traders','Hafiz Uddin','01921-100103','','','','Cumilla Sadar','Cumilla Sadar','araihazar','narayanganj','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-18 11:24:02','admin-id','2026-01-25 05:35:58',2),
('521e18fc-b57a-48c4-a0a7-d7772edb4b76','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Customer','Local','M/S Amin Enterprise','Aminul Islam','01534-100105','','','','Khulna Boyra','Khulna Boyra','kachpur','narayanganj','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-18 11:24:45','admin-id','2026-01-25 05:37:18',2),
('639611f4-97e5-4589-904e-190ef11f7f4e','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Supplier','Local','Jisan Dairy Source','Akhi Khatun','01555-000005','','','','Mirpur-10, Dhaka','Mirpur-10, Dhaka','enayetpur','sirajganj','Bangladesh','0',0.000000,25000.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-18 11:10:29','admin-id','2026-01-25 05:37:05',2),
('6a0619ca-84e9-4df5-b225-7dd7acb91b86','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Supplier','Local','Green Farm Ltd.','Abdul Karim','01933-000003','','','','Bogura Sadar, Bogura','Bogura Sadar, Bogura','bogra-sadar','bogra','Bangladesh','0',10.000000,0.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-18 11:09:12','admin-id','2026-01-25 05:35:12',2),
('be93309a-ec2b-40d0-9c62-8abe7796b547','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Supplier','Local','Golden Grain Supply','Rashed Mahmud','01644-000004','','','','Jashore Industrial Area','Jashore Industrial Area','kamarkhanda','sirajganj','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-18 11:09:47','admin-id','2026-01-25 05:36:57',2),
('both','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Both','Local','Both A/C','Both A/C','Both A/C','Both A/C','','','Both A/C','Both A/C','sherpur','bogra','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-09 13:04:25','admin-id','2026-01-25 05:36:12',3),
('c370a9f5-7ccf-4e2d-9d7a-7d5873293ddc','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Customer','Local','Shapno Mini Mart','Farzana Islam','01819-100102','email@sgd.com','','','Uttara Sector 7, Dhaka','Uttara Sector 7, Dhaka','belkuchi','sirajganj','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'admin-id','2026-01-14 09:23:59','admin-id','2026-01-25 05:36:25',3),
('d5eefaf0-9979-4edf-8fbd-68f3157c4105','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Customer','Local','Rahman General Store','Anisur Rahman','01712-100101','email@email.com','','','Mohammadpur, Dhaka','Mohammadpur, Dhaka','adamdighi','bogra','Bangladesh','0',0.000000,50000.000000,0.000000,0.000000,0.000000,1,'4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-09 12:02:29','admin-id','2026-01-25 05:36:40',4),
('internal','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Internal','Local','Internal A/C','Internal A/C','Internal A/C','Internal A/C','','','Internal A/C','Internal A/C','sherpur','bogra','Bangladesh','0',0.000000,0.000000,0.000000,0.000000,0.000000,1,'4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-09 13:04:25','admin-id','2026-01-25 05:37:31',3);
/*!40000 ALTER TABLE `tmcb_cntct` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmcb_dzone`
--

DROP TABLE IF EXISTS `tmcb_dzone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_dzone` (
  `id` varchar(50) NOT NULL,
  `dzone_users` varchar(50) NOT NULL,
  `dzone_bsins` varchar(50) NOT NULL,
  `dzone_cntry` varchar(50) NOT NULL,
  `dzone_dname` varchar(50) NOT NULL,
  `dzone_actve` tinyint(1) NOT NULL DEFAULT 1,
  `dzone_crusr` varchar(50) NOT NULL,
  `dzone_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `dzone_upusr` varchar(50) NOT NULL,
  `dzone_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dzone_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_dzone`
--

LOCK TABLES `tmcb_dzone` WRITE;
/*!40000 ALTER TABLE `tmcb_dzone` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmcb_dzone` VALUES
('bogra','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','Bangladesh','Bogra',1,'admin-id','2026-01-25 04:45:54','admin-id','2026-01-25 04:46:18',1),
('narayanganj','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','Bangladesh','Narayanganj',1,'admin-id','2026-01-25 04:45:54','admin-id','2026-01-25 04:46:18',1),
('sirajganj','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','Bangladesh','Sirajganj',1,'admin-id','2026-01-25 04:45:54','admin-id','2026-01-25 04:46:20',1);
/*!40000 ALTER TABLE `tmcb_dzone` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmcb_rutes`
--

DROP TABLE IF EXISTS `tmcb_rutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_rutes` (
  `id` varchar(50) NOT NULL,
  `rutes_users` varchar(50) NOT NULL,
  `rutes_bsins` varchar(50) NOT NULL,
  `rutes_rname` varchar(50) NOT NULL,
  `rutes_dname` varchar(50) NOT NULL,
  `rutes_sraid` varchar(50) NOT NULL,
  `rutes_lvdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rutes_ttcnt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_odval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_dlval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_clval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_duval` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rutes_actve` tinyint(1) NOT NULL DEFAULT 1,
  `rutes_crusr` varchar(50) NOT NULL,
  `rutes_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rutes_upusr` varchar(50) NOT NULL,
  `rutes_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rutes_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_rutes`
--

LOCK TABLES `tmcb_rutes` WRITE;
/*!40000 ALTER TABLE `tmcb_rutes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmcb_rutes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmcb_tarea`
--

DROP TABLE IF EXISTS `tmcb_tarea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmcb_tarea` (
  `id` varchar(50) NOT NULL,
  `tarea_users` varchar(50) NOT NULL,
  `tarea_bsins` varchar(50) NOT NULL,
  `tarea_dzone` varchar(50) NOT NULL,
  `tarea_tname` varchar(50) NOT NULL,
  `tarea_actve` tinyint(1) NOT NULL DEFAULT 1,
  `tarea_crusr` varchar(50) NOT NULL,
  `tarea_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tarea_upusr` varchar(50) NOT NULL,
  `tarea_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tarea_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmcb_tarea`
--

LOCK TABLES `tmcb_tarea` WRITE;
/*!40000 ALTER TABLE `tmcb_tarea` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmcb_tarea` VALUES
('adamdighi','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Adamdighi',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('araihazar','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Araihazar',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('bandar','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Bandar',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('belkuchi','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Belkuchi',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:29:10',1),
('bhairob','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Bhairob',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('bogra-sadar','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Bogra Sadar',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('chauhali','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Chauhali',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:26',1),
('dhunat','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Dhunat',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('dhupchanchia','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Dhupchanchia',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('enayetpur','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Enayetpur',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:26',1),
('gabtali','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Gabtali',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('jamuna-river','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Jamuna River',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:29:10',1),
('kachpur','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Kachpur',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('kahaloo','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Kahaloo',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('kamarkhanda','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Kamarkhanda',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:26:55',1),
('kazipur','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Kazipur',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:26',1),
('nandigram','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Nandigram',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('narayanganj-city-corporation','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Narayanganj City Corporation',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('narayanganj-sadar','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Narayanganj Sadar',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('raiganj','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Raiganj',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:29:10',1),
('rupganj','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Rupganj',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('sariakandi','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Sariakandi',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('shahjadpur','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Shahjadpur',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:26',1),
('shajahanpur','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Shajahanpur',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('sherpur','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Sherpur',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('shibganj','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Shibganj',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('sirajganj-sadar','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Sirajganj Sadar',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:26',1),
('sonargaon','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','narayanganj','Sonargaon',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1),
('sonatala','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','bogra','Sonatala',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 04:58:23',1),
('tarash','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','sirajganj','Tarash',1,'admin-id','2026-01-25 04:57:51','admin-id','2026-01-25 05:19:19',1);
/*!40000 ALTER TABLE `tmcb_tarea` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_attrb`
--

DROP TABLE IF EXISTS `tmib_attrb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_attrb` (
  `id` varchar(50) NOT NULL,
  `attrb_users` varchar(50) NOT NULL,
  `attrb_aname` varchar(50) NOT NULL,
  `attrb_dtype` varchar(50) NOT NULL,
  `attrb_actve` tinyint(1) NOT NULL DEFAULT 1,
  `attrb_crusr` varchar(50) NOT NULL,
  `attrb_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `attrb_upusr` varchar(50) NOT NULL,
  `attrb_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `attrb_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_attrb`
--

LOCK TABLES `tmib_attrb` WRITE;
/*!40000 ALTER TABLE `tmib_attrb` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_attrb` VALUES
('color','admin-id','Color','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:38:19',1),
('expiry','admin-id','Expiry','date',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:42:46',1),
('fabric','admin-id','Fabric','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:38:19',1),
('height','admin-id','Height','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:38:19',1),
('imei','admin-id','IMEI','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:40:47',1),
('model','admin-id','Model','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:38:19',1),
('serialno','admin-id','Serial No','number',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:38:19',1),
('size','admin-id','Size','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 08:24:21',1),
('weight','admin-id','Weight','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 08:24:21',1),
('width','admin-id','Width','text',1,'admin-id','2026-01-25 07:38:19','admin-id','2026-01-25 07:38:19',1);
/*!40000 ALTER TABLE `tmib_attrb` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_bitem`
--

DROP TABLE IF EXISTS `tmib_bitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_bitem` (
  `id` varchar(50) NOT NULL,
  `bitem_users` varchar(50) NOT NULL,
  `bitem_items` varchar(50) NOT NULL,
  `bitem_bsins` varchar(50) NOT NULL,
  `bitem_lprat` decimal(20,6) DEFAULT 0.000000,
  `bitem_dprat` decimal(20,6) DEFAULT 0.000000,
  `bitem_mcmrp` decimal(20,6) DEFAULT 0.000000,
  `bitem_sddsp` decimal(20,6) DEFAULT 0.000000,
  `bitem_snote` varchar(100) DEFAULT NULL,
  `bitem_gstkq` decimal(20,6) DEFAULT 0.000000,
  `bitem_bstkq` decimal(20,6) DEFAULT 0.000000,
  `bitem_mnqty` decimal(20,6) DEFAULT 1.000000,
  `bitem_mxqty` decimal(20,6) DEFAULT 1.000000,
  `bitem_pbqty` decimal(20,6) DEFAULT 0.000000,
  `bitem_sbqty` decimal(20,6) DEFAULT 0.000000,
  `bitem_mpric` decimal(20,6) DEFAULT 0.000000,
  `bitem_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bitem_crusr` varchar(50) NOT NULL,
  `bitem_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bitem_upusr` varchar(50) NOT NULL,
  `bitem_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bitem_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_bitem`
--

LOCK TABLES `tmib_bitem` WRITE;
/*!40000 ALTER TABLE `tmib_bitem` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_bitem` VALUES
('0a73b49d-71b3-4671-9c09-6d985f3514fc','admin-id','485d61c3-e84e-418b-b91b-2171c17f0391','3881b053-9509-49db-835a-3f8dd8976cda',260.000000,0.000000,377.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,70.200000,1,'admin-id','2026-01-18 11:54:40','admin-id','2026-01-27 12:18:39',1),
('0b9c71ef-77de-4116-8298-ac0898e2d217','admin-id','ae0a4ae3-77f6-4357-8ca9-c05cc1796a7e','3881b053-9509-49db-835a-3f8dd8976cda',10.000000,0.000000,15.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,3.000000,1,'admin-id','2026-01-18 11:33:26','admin-id','2026-01-27 12:18:39',1),
('22064b47-6898-4661-9dc8-5329a542ae4a','admin-id','24614ec4-8ab0-4b50-b3c7-9f154a124770','3881b053-9509-49db-835a-3f8dd8976cda',110.000000,0.000000,154.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,285.000000,0.000000,26.400000,1,'admin-id','2026-01-18 11:48:18','admin-id','2026-01-30 11:48:07',1),
('22bbdf6e-759b-4b46-a0a6-b5d2a8d7d383','admin-id','dfe206f2-b3a3-4d6c-8b3c-7402582348eb','3881b053-9509-49db-835a-3f8dd8976cda',15.000000,0.000000,22.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,4.300000,1,'admin-id','2026-01-18 11:40:04','admin-id','2026-01-27 12:18:39',1),
('49637732-1033-454e-8690-e4162e763fdd','admin-id','8873e069-eea6-4f9e-acf0-dd1cb658f9c8','3881b053-9509-49db-835a-3f8dd8976cda',18.000000,0.000000,25.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,4.300000,1,'admin-id','2026-01-18 12:20:40','admin-id','2026-01-18 12:20:40',1),
('69b3b567-0009-48b6-abf3-5701e00ab0e1','admin-id','ad014a04-77d0-4f46-acc9-dee2b02c64f2','3881b053-9509-49db-835a-3f8dd8976cda',22.000000,0.000000,32.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,6.040000,1,'admin-id','2026-01-18 12:22:53','admin-id','2026-01-27 12:18:39',1),
('73a91ad4-50f1-4b8b-8a93-ad00e7829c8f','admin-id','4b100c2e-68a6-467b-94b7-617a6c7b43dc','3881b053-9509-49db-835a-3f8dd8976cda',85.000000,0.000000,128.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,26.000000,1,'admin-id','2026-01-18 12:10:02','admin-id','2026-01-18 12:10:02',1),
('7df55d16-a7c1-4e85-94a2-67f826401fe6','admin-id','471d3f7f-e3e5-4585-bdbf-5f0a35b05a93','3881b053-9509-49db-835a-3f8dd8976cda',140.000000,0.000000,203.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,37.800000,1,'admin-id','2026-01-18 12:11:01','admin-id','2026-01-27 12:18:39',1),
('803770fe-3449-41e5-b2e1-50d2a02b6872','admin-id','940f8010-5d38-4de4-b66f-d12958ff9ecf','3881b053-9509-49db-835a-3f8dd8976cda',120.000000,0.000000,180.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,42.000000,1,'admin-id','2026-01-18 11:41:51','admin-id','2026-01-27 14:41:16',1),
('854996eb-cabc-487b-a5bc-692bfffe2689','admin-id','75b05c78-9b6b-42ba-aafa-e76e22f67722','3881b053-9509-49db-835a-3f8dd8976cda',28.000000,0.000000,42.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,8.400000,1,'admin-id','2026-01-18 12:05:52','admin-id','2026-01-18 12:05:52',1),
('921ea45d-ceac-4f42-ac69-3b17c74a590b','admin-id','4b019cba-eda8-4ad3-a8ac-ece0e6478ffe','3881b053-9509-49db-835a-3f8dd8976cda',12.000000,0.000000,16.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,2.320000,1,'admin-id','2026-01-18 12:21:38','admin-id','2026-01-18 12:21:38',1),
('9a08c3f7-2154-4cb5-ad90-8346f705f6f5','admin-id','2bee4dba-5f29-4e65-b772-718c677e326c','3881b053-9509-49db-835a-3f8dd8976cda',20.000000,0.000000,30.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,6.000000,1,'admin-id','2026-01-18 12:24:01','admin-id','2026-01-18 12:24:01',1),
('a06cf515-c579-4628-96c4-c1f88f0d9308','admin-id','42ccd66a-70db-4c7f-93c4-36261a8f064f','3881b053-9509-49db-835a-3f8dd8976cda',90.000000,0.000000,126.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,18.000000,1,'admin-id','2026-01-18 11:53:22','admin-id','2026-01-27 01:20:49',1),
('a5da4ada-2216-49a6-bfde-aa71f0de6bb8','admin-id','38b496e9-6652-4324-8331-ba0ecb0cfeae','3881b053-9509-49db-835a-3f8dd8976cda',60.000000,0.000000,78.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,20.000000,0.000000,9.000000,1,'admin-id','2026-01-18 11:51:19','admin-id','2026-01-30 11:48:07',1),
('bfa793e3-23b6-4472-96e7-2b13bb70f476','admin-id','b3da1017-bea4-44fd-ad13-110e92a48965','3881b053-9509-49db-835a-3f8dd8976cda',40.000000,0.000000,51.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,6.200000,1,'admin-id','2026-01-18 11:49:13','admin-id','2026-01-18 11:49:13',1),
('c9dcd99f-c04f-44f0-8778-d33c7cfc068c','admin-id','940f8010-5d38-4de4-b66f-d12958ff9ec2','3881b053-9509-49db-835a-3f8dd8976cda',52.000000,0.000000,70.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,10.200000,1,'admin-id','2026-01-18 11:46:22','admin-id','2026-01-21 07:20:11',1),
('cc4ea99b-527d-477d-8153-1a831b35d4de','admin-id','0e5de4e6-86dd-453a-8b94-963ee305e860','3881b053-9509-49db-835a-3f8dd8976cda',95.000000,0.000000,133.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,22.800000,1,'admin-id','2026-01-18 12:08:53','admin-id','2026-01-18 12:08:53',1),
('d0249c21-993f-40a7-9819-d05b046d8591','admin-id','e2e70dc1-9814-400c-8774-2b6b186b79e5','3881b053-9509-49db-835a-3f8dd8976cda',180.000000,0.000000,252.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,39.600000,1,'admin-id','2026-01-18 11:55:39','admin-id','2026-01-27 14:41:16',1),
('d9dfcad2-2bdd-4770-86e3-448c75efabe7','admin-id','2c047e91-44f6-48bc-a591-9ab00deb7b72','3881b053-9509-49db-835a-3f8dd8976cda',95.000000,0.000000,128.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,18.750000,1,'admin-id','2026-01-18 11:49:59','admin-id','2026-01-18 11:49:59',1),
('e27daa49-9065-4e51-9dd5-246c1451d264','admin-id','f949a24a-3ff8-4349-9ca0-f853de9226c7','3881b053-9509-49db-835a-3f8dd8976cda',110.000000,0.000000,160.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,30.200000,1,'admin-id','2026-01-18 12:07:47','admin-id','2026-01-18 12:07:47',1),
('f79040d1-8a63-4b4a-a515-16796fd56797','admin-id','4dab149a-e220-4cd8-a061-7660ab0168bb','3881b053-9509-49db-835a-3f8dd8976cda',58.000000,0.000000,75.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,8.880000,1,'admin-id','2026-01-18 11:47:21','admin-id','2026-01-21 07:20:11',1),
('f7c7bdba-dbb1-47e2-95f7-8710f9267b6a','admin-id','f7126510-80c0-416b-a34e-3a514e54d030','3881b053-9509-49db-835a-3f8dd8976cda',25.000000,0.000000,35.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,6.250000,1,'admin-id','2026-01-18 12:24:55','admin-id','2026-01-18 12:24:55',1),
('f9d0b5e0-8d00-4309-b885-45e41b1297d0','admin-id','e483bc2d-6ccd-4b72-8603-775dcd275249','3881b053-9509-49db-835a-3f8dd8976cda',420.000000,0.000000,546.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,84.000000,1,'admin-id','2026-01-18 11:44:14','admin-id','2026-01-27 14:41:16',1),
('fc0f7f6f-048a-4512-b614-79b13efa72bd','admin-id','fa1b188a-c075-4b90-bbea-37e3733f50bb','3881b053-9509-49db-835a-3f8dd8976cda',580.000000,0.000000,783.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,98.600000,1,'admin-id','2026-01-18 11:52:30','admin-id','2026-01-20 10:49:29',1),
('fdfa97ae-9622-4548-bc27-4cf8a163cfa3','admin-id','e45670a3-981c-47c2-bd6a-a02bd8c0d7b0','3881b053-9509-49db-835a-3f8dd8976cda',160.000000,0.000000,219.000000,0.000000,'',0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,39.800000,1,'admin-id','2026-01-18 11:43:14','admin-id','2026-01-18 11:43:14',1);
/*!40000 ALTER TABLE `tmib_bitem` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_ctgry`
--

DROP TABLE IF EXISTS `tmib_ctgry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_ctgry` (
  `id` varchar(50) NOT NULL,
  `ctgry_users` varchar(50) NOT NULL,
  `ctgry_ctgnm` varchar(50) NOT NULL,
  `ctgry_actve` tinyint(1) NOT NULL DEFAULT 1,
  `ctgry_crusr` varchar(50) NOT NULL,
  `ctgry_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ctgry_upusr` varchar(50) NOT NULL,
  `ctgry_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ctgry_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_ctgry`
--

LOCK TABLES `tmib_ctgry` WRITE;
/*!40000 ALTER TABLE `tmib_ctgry` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_ctgry` VALUES
('204e4887-0af6-4908-add0-240ea380a53b','admin-id','Household Essentials',1,'admin-id','2026-01-11 05:06:00','admin-id','2026-01-18 11:29:46',1),
('36886293-b080-44dc-9c8e-fed94ad161d3','admin-id','Rice & Grain',1,'admin-id','2026-01-11 05:04:19','admin-id','2026-01-18 11:29:19',1),
('3ed137d4-3863-407a-8f4a-dd1000479780','admin-id','Dairy Products',1,'admin-id','2026-01-11 05:04:25','admin-id','2026-01-18 11:29:36',1),
('b1df68d6-2888-42c7-a3a8-cdaedadf5408','admin-id','Toys and Gears',1,'admin-id','2026-01-11 05:04:47','admin-id','2026-01-18 11:30:21',1),
('e69fe3b2-784f-44d5-9d88-4c228704242f','admin-id','Eggs & Poultry',1,'admin-id','2026-01-11 05:04:10','admin-id','2026-01-18 11:29:01',1),
('feacdbbe-2519-4975-96fe-ad18c7899b53','admin-id','Beverages & Snacks',1,'admin-id','2026-01-11 05:03:50','admin-id','2026-01-22 10:52:51',1);
/*!40000 ALTER TABLE `tmib_ctgry` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_ctrsf`
--

DROP TABLE IF EXISTS `tmib_ctrsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_ctrsf` (
  `id` varchar(50) NOT NULL,
  `ctrsf_mtrsf` varchar(50) NOT NULL,
  `ctrsf_bitem` varchar(50) NOT NULL,
  `ctrsf_items` varchar(50) NOT NULL,
  `ctrsf_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_notes` varchar(50) DEFAULT NULL,
  `ctrsf_attrb` varchar(300) DEFAULT NULL,
  `ctrsf_rtqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_slqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_ohqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `ctrsf_srcnm` varchar(50) NOT NULL,
  `ctrsf_refid` varchar(50) NOT NULL,
  `ctrsf_actve` tinyint(1) NOT NULL DEFAULT 1,
  `ctrsf_crusr` varchar(50) NOT NULL,
  `ctrsf_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ctrsf_upusr` varchar(50) NOT NULL,
  `ctrsf_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ctrsf_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_ctrsf`
--

LOCK TABLES `tmib_ctrsf` WRITE;
/*!40000 ALTER TABLE `tmib_ctrsf` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_ctrsf` VALUES
('107792d2-0dca-4eb8-9364-50b7559ad221','edad1143-07e5-4cdb-a2c4-d2e4a679ba17','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,100.000000,11000.000000,110.000000,11000.000000,'0','{}',0.000000,0.000000,100.000000,'Purchase Receipt','cbdcede5-1100-4cbb-9eff-99de1526e263',1,'admin-id','2026-01-30 04:24:22','admin-id','2026-01-30 04:24:22',1),
('114a066d-75cb-49ac-8a66-62b9bf596647','0d9af1be-dfbd-4e1e-b92c-eb5d9637e189','a5da4ada-2216-49a6-bfde-aa71f0de6bb8','38b496e9-6652-4324-8331-ba0ecb0cfeae',60.000000,50.000000,3000.000000,60.000000,3000.000000,'0','{\"Size\":\"5 Ltr\"}',0.000000,0.000000,50.000000,'Purchase Invoice','568fb2f5-424b-4827-a642-83cb5c641b6a',1,'admin-id','2026-01-30 03:32:35','admin-id','2026-01-30 03:32:35',1),
('49c8a108-e88a-4a56-93e7-eff102cba401','f5a4e363-8ee1-4e73-a942-8768a95018b5','d0249c21-993f-40a7-9819-d05b046d8591','e2e70dc1-9814-400c-8774-2b6b186b79e5',180.000000,50.000000,9000.000000,180.000000,9000.000000,'0','{}',0.000000,0.000000,50.000000,'Purchase Invoice','76217258-3c3c-4b22-b7fe-5966d5f00d3e',1,'admin-id','2026-01-30 04:24:09','admin-id','2026-01-30 04:24:09',1),
('726044d1-f54e-4c43-ab5f-5b05231c7c71','9ddf27e1-87ce-4eda-96a7-5bca832984bc','73a91ad4-50f1-4b8b-8a93-ad00e7829c8f','4b100c2e-68a6-467b-94b7-617a6c7b43dc',85.000000,10.000000,850.000000,85.000000,850.000000,'0','{}',0.000000,0.000000,10.000000,'Purchase Invoice','ff5a866c-c546-48c5-906a-3a0835492a82',1,'admin-id','2026-01-30 04:26:26','admin-id','2026-01-30 04:26:26',1),
('8f0b27cd-8ca7-44b5-9dbf-a90e11387cac','0d9af1be-dfbd-4e1e-b92c-eb5d9637e189','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,50.000000,5500.000000,110.000000,5500.000000,'0','{}',0.000000,0.000000,50.000000,'Purchase Receipt','20e07a84-156d-44b3-a107-9020f719bff8',1,'admin-id','2026-01-30 03:32:35','admin-id','2026-01-30 03:32:35',1),
('d8123a7f-fab9-4cc7-a3fc-95a9ea6f6810','42dccf1f-1c32-4d8f-856d-36caf8a414b9','22bbdf6e-759b-4b46-a0a6-b5d2a8d7d383','dfe206f2-b3a3-4d6c-8b3c-7402582348eb',15.000000,250.000000,3750.000000,15.000000,3750.000000,'0','{}',0.000000,0.000000,250.000000,'Purchase Invoice','ae18984e-bf0b-496e-b691-923b26d7bb2a',1,'admin-id','2026-01-30 04:16:15','admin-id','2026-01-30 04:16:15',1),
('ec68fb29-da4f-4650-917b-655f18500f4f','2cd28473-8e12-4222-9d22-a7b981d235dc','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,50.000000,5500.000000,110.000000,5500.000000,'0','{}',0.000000,0.000000,50.000000,'Purchase Receipt','0f1de64b-740f-4b3f-8b0e-ead54e46d4a6',1,'admin-id','2026-01-30 04:25:09','admin-id','2026-01-30 04:25:09',1);
/*!40000 ALTER TABLE `tmib_ctrsf` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_items`
--

DROP TABLE IF EXISTS `tmib_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_items` (
  `id` varchar(50) NOT NULL,
  `items_users` varchar(50) NOT NULL,
  `items_icode` varchar(50) DEFAULT NULL,
  `items_bcode` varchar(50) DEFAULT NULL,
  `items_hscod` varchar(50) DEFAULT NULL,
  `items_iname` varchar(100) NOT NULL,
  `items_idesc` varchar(100) DEFAULT NULL,
  `items_puofm` varchar(50) NOT NULL,
  `items_dfqty` int(11) NOT NULL DEFAULT 1,
  `items_suofm` varchar(50) NOT NULL,
  `items_ctgry` varchar(50) NOT NULL,
  `items_itype` varchar(50) NOT NULL,
  `items_hwrnt` int(11) NOT NULL DEFAULT 0,
  `items_hxpry` int(11) NOT NULL DEFAULT 0,
  `items_sdvat` decimal(4,2) DEFAULT 0.00,
  `items_costp` decimal(4,2) DEFAULT 0.00,
  `items_image` varchar(50) DEFAULT NULL,
  `items_nofbi` int(11) NOT NULL DEFAULT 0,
  `items_actve` tinyint(1) NOT NULL DEFAULT 1,
  `items_crusr` varchar(50) NOT NULL,
  `items_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `items_upusr` varchar(50) NOT NULL,
  `items_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `items_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_items`
--

LOCK TABLES `tmib_items` WRITE;
/*!40000 ALTER TABLE `tmib_items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_items` VALUES
('0e5de4e6-86dd-453a-8b94-963ee305e860','admin-id','HE-003','HE-003','HE-003','Floor Cleaner','Floor Cleaner','1f240f2c-50ab-407f-b77d-0ce95922fd6c',1,'1f240f2c-50ab-407f-b77d-0ce95922fd6c','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,0,7.50,16.00,NULL,1,1,'admin-id','2026-01-18 12:08:34','admin-id','2026-01-18 12:08:53',1),
('24614ec4-8ab0-4b50-b3c7-9f154a124770','admin-id','RG-003','RG-003','RG-003','Basmati Rice','Basmati Rice','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,0,5.00,16.00,NULL,1,1,'admin-id','2026-01-12 06:16:06','admin-id','2026-01-18 11:48:18',1),
('2bee4dba-5f29-4e65-b772-718c677e326c','admin-id','BS-004','BS-004','BS-004','Potato Chips','Potato Chips','344eb4c8-48c4-475b-b74c-307a0e492622',20,'f5ccd3c1-fd1e-4f0e-93be-59dd878c881a','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,0,10.00,20.00,NULL,1,1,'admin-id','2026-01-18 12:23:51','admin-id','2026-01-18 12:24:01',1),
('2c047e91-44f6-48bc-a591-9ab00deb7b72','admin-id','RG-005','RG-005','RG-005','Masur Dal','Masur Dal','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,0,5.00,15.00,NULL,1,1,'admin-id','2026-01-18 11:49:45','admin-id','2026-01-18 11:49:59',1),
('38b496e9-6652-4324-8331-ba0ecb0cfeae','admin-id','DP-001','DP-001','DP-001','Fresh Milk','Fresh Milk','1f240f2c-50ab-407f-b77d-0ce95922fd6c',1,'1f240f2c-50ab-407f-b77d-0ce95922fd6c','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,0,5.00,15.00,NULL,1,1,'admin-id','2026-01-18 11:51:08','admin-id','2026-01-18 11:51:19',1),
('42ccd66a-70db-4c7f-93c4-36261a8f064f','admin-id','DP-003','DP-003','DP-003','Yogurt','Yogurt','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,0,5.00,20.00,NULL,1,1,'admin-id','2026-01-18 11:53:02','admin-id','2026-01-18 11:53:22',1),
('471d3f7f-e3e5-4585-bdbf-5f0a35b05a93','admin-id','HE-005','HE-005','HE-005','Tissue Roll','Tissue Roll','344eb4c8-48c4-475b-b74c-307a0e492622',6,'78a63632-6a35-49ab-8cac-4b5c0d4fb418','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,0,7.50,18.00,NULL,1,1,'admin-id','2026-01-18 12:10:46','admin-id','2026-01-18 12:11:01',1),
('485d61c3-e84e-418b-b91b-2171c17f0391','admin-id','DP-004','DP-004','DP-004','Butter','Butter','344eb4c8-48c4-475b-b74c-307a0e492622',1,'344eb4c8-48c4-475b-b74c-307a0e492622','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,0,5.00,18.00,NULL,1,1,'admin-id','2026-01-18 11:54:16','admin-id','2026-01-18 11:54:40',1),
('4b019cba-eda8-4ad3-a8ac-ece0e6478ffe','admin-id','BS-002','BS-002','BS-002','Mineral Water 1L','Mineral Water 1L','344eb4c8-48c4-475b-b74c-307a0e492622',12,'c1ab2f8e-5030-40a4-85a3-569ad7cc6dd7','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,0,10.00,14.00,NULL,1,1,'admin-id','2026-01-18 12:21:19','admin-id','2026-01-18 12:21:38',1),
('4b100c2e-68a6-467b-94b7-617a6c7b43dc','admin-id','HE-004','HE-004','HE-004','Toilet Cleaner','Toilet Cleaner','344eb4c8-48c4-475b-b74c-307a0e492622',6,'78a63632-6a35-49ab-8cac-4b5c0d4fb418','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,0,7.50,20.00,NULL,1,1,'admin-id','2026-01-18 12:09:36','admin-id','2026-01-18 12:10:02',1),
('4dab149a-e220-4cd8-a061-7660ab0168bb','admin-id','RG-002','RG-002','RG-002','Nazirshail Rice','Nazirshail Rice','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,0,5.00,14.00,NULL,1,1,'admin-id','2026-01-12 06:20:57','admin-id','2026-01-18 11:47:21',1),
('75b05c78-9b6b-42ba-aafa-e76e22f67722','admin-id','HE-001','HE-001','HE-001','Laundry Soap','Laundry Soap','344eb4c8-48c4-475b-b74c-307a0e492622',12,'78a63632-6a35-49ab-8cac-4b5c0d4fb418','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,0,7.50,20.00,NULL,1,1,'admin-id','2026-01-18 12:05:41','admin-id','2026-01-18 12:05:52',1),
('8873e069-eea6-4f9e-acf0-dd1cb658f9c8','admin-id','BS-001','BS-001','BS-001','Soft Drink 250ml','Soft Drink 250ml','344eb4c8-48c4-475b-b74c-307a0e492622',24,'f5d78785-c08b-46b7-a77f-dcf1a8700dd0','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,0,10.00,15.00,NULL,1,1,'admin-id','2026-01-18 12:20:20','admin-id','2026-01-18 12:20:40',1),
('940f8010-5d38-4de4-b66f-d12958ff9ec2','admin-id','RG-001','RG-001','RG-001','Miniket Rice','Miniket Rice','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,0,5.00,15.00,NULL,1,1,'940f8010-5d38-4de4-b66f-d12958ff9ecf','2026-01-11 06:06:23','admin-id','2026-01-18 11:46:22',1),
('940f8010-5d38-4de4-b66f-d12958ff9ecf','admin-id','EP-003','EP-003','EP-003','Layer Egg (Dozen)','Layer Egg (Dozen)','61accd0f-ebd7-4c2c-9e33-ba5f92e091d1',30,'f5d78785-c08b-46b7-a77f-dcf1a8700dd0','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,0,5.00,15.00,NULL,1,1,'940f8010-5d38-4de4-b66f-d12958ff9ecf','2026-01-11 06:06:23','admin-id','2026-01-18 11:41:51',1),
('ad014a04-77d0-4f46-acc9-dee2b02c64f2','admin-id','BS-003','BS-003','BS-003','Juice Pack','Juice Pack','344eb4c8-48c4-475b-b74c-307a0e492622',10,'cdd3a6c9-d31b-4a41-8762-69700e2a1108','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,0,10.00,18.00,NULL,1,1,'admin-id','2026-01-18 12:22:34','admin-id','2026-01-18 12:22:53',1),
('ae0a4ae3-77f6-4357-8ca9-c05cc1796a7e','admin-id','EP-001','EP-001','EP-001','Layer Egg','Layer Egg','344eb4c8-48c4-475b-b74c-307a0e492622',12,'61accd0f-ebd7-4c2c-9e33-ba5f92e091d1','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,0,5.00,20.00,NULL,1,1,'admin-id','2026-01-12 06:17:33','admin-id','2026-01-18 11:38:30',1),
('b3da1017-bea4-44fd-ad13-110e92a48965','admin-id','RG-004','RG-004','RG-004','Wheat','Wheat','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','36886293-b080-44dc-9c8e-fed94ad161d3','Finished Goods',0,0,5.00,12.00,NULL,1,1,'admin-id','2026-01-18 11:49:00','admin-id','2026-01-18 11:49:13',1),
('dfe206f2-b3a3-4d6c-8b3c-7402582348eb','admin-id','EP-002','EP-002','EP-002','Duck Egg','Duck Egg','344eb4c8-48c4-475b-b74c-307a0e492622',12,'61accd0f-ebd7-4c2c-9e33-ba5f92e091d1','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,0,5.00,18.00,NULL,1,1,'admin-id','2026-01-12 06:38:50','admin-id','2026-01-18 11:39:37',1),
('e2e70dc1-9814-400c-8774-2b6b186b79e5','admin-id','DP-005','DP-005','DP-005','Cheese Slice','Cheese Slice','344eb4c8-48c4-475b-b74c-307a0e492622',10,'50d3582c-909a-4818-afd7-54a8db8c1a44','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,0,5.00,18.00,NULL,1,1,'admin-id','2026-01-18 11:55:20','admin-id','2026-01-18 11:55:39',1),
('e45670a3-981c-47c2-bd6a-a02bd8c0d7b0','admin-id','EP-004','EP-004','EP-004','Broiler Chicken','Broiler Chicken','f13c1fb3-3493-4640-9b13-02bd824b4977',1000,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,0,5.00,12.00,NULL,1,1,'admin-id','2026-01-11 06:38:46','admin-id','2026-01-18 11:55:58',1),
('e483bc2d-6ccd-4b72-8603-775dcd275249','admin-id','EP-005','EP-005','EP-005','Deshi Chicken','Deshi Chicken','f13c1fb3-3493-4640-9b13-02bd824b4977',1000,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','e69fe3b2-784f-44d5-9d88-4c228704242f','Finished Goods',0,0,5.00,10.00,NULL,1,1,'admin-id','2026-01-12 06:12:16','admin-id','2026-01-18 11:44:14',1),
('f7126510-80c0-416b-a34e-3a514e54d030','admin-id','BS-005','BS-005','BS-005','Biscuit','Biscuit','344eb4c8-48c4-475b-b74c-307a0e492622',12,'50d3582c-909a-4818-afd7-54a8db8c1a44','feacdbbe-2519-4975-96fe-ad18c7899b53','Finished Goods',0,0,10.00,15.00,NULL,1,1,'admin-id','2026-01-18 12:24:41','admin-id','2026-01-18 12:24:55',1),
('f949a24a-3ff8-4349-9ca0-f853de9226c7','admin-id','HE-002','HE-002','HE-002','Dishwashing Liquid','Dishwashing Liquid','1f240f2c-50ab-407f-b77d-0ce95922fd6c',1,'1f240f2c-50ab-407f-b77d-0ce95922fd6c','204e4887-0af6-4908-add0-240ea380a53b','Finished Goods',0,0,7.50,18.00,NULL,1,1,'admin-id','2026-01-18 12:06:48','admin-id','2026-01-18 12:07:47',1),
('fa1b188a-c075-4b90-bbea-37e3733f50bb','admin-id','DP-002','DP-002','DP-002','Powder Milk','Powder Milk','22b30ed6-ee7a-421d-a9a3-dc6c710b9229',1,'22b30ed6-ee7a-421d-a9a3-dc6c710b9229','3ed137d4-3863-407a-8f4a-dd1000479780','Finished Goods',0,0,5.00,18.00,NULL,1,1,'admin-id','2026-01-18 11:52:20','admin-id','2026-01-18 11:52:30',1);
/*!40000 ALTER TABLE `tmib_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_iuofm`
--

DROP TABLE IF EXISTS `tmib_iuofm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_iuofm` (
  `id` varchar(50) NOT NULL,
  `iuofm_users` varchar(50) NOT NULL,
  `iuofm_untnm` varchar(50) NOT NULL,
  `iuofm_untgr` varchar(50) DEFAULT NULL,
  `iuofm_actve` tinyint(1) NOT NULL DEFAULT 1,
  `iuofm_crusr` varchar(50) NOT NULL,
  `iuofm_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `iuofm_upusr` varchar(50) NOT NULL,
  `iuofm_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `iuofm_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_iuofm`
--

LOCK TABLES `tmib_iuofm` WRITE;
/*!40000 ALTER TABLE `tmib_iuofm` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_iuofm` VALUES
('024a6dbf-85cb-48d6-91e0-41f4b977bcd4','admin-id','Ml','Volume',1,'admin-id','2026-01-18 12:07:30','admin-id','2026-01-18 12:07:30',1),
('1f240f2c-50ab-407f-b77d-0ce95922fd6c','admin-id','Ltr','Volume',1,'admin-id','2026-01-11 04:40:38','admin-id','2026-01-18 12:06:59',1),
('2276a903-fc68-4c43-8448-8ceab9aee99d','admin-id','Bulk','Mass',1,'admin-id','2026-01-12 06:39:04','admin-id','2026-01-14 08:32:20',1),
('22b30ed6-ee7a-421d-a9a3-dc6c710b9229','admin-id','Kg','Weight',1,'admin-id','2026-01-11 04:43:41','admin-id','2026-01-14 08:32:24',1),
('2993fee8-3e34-4e2e-8cb9-63461934a6ef','admin-id','Inch','Length',1,'admin-id','2026-01-14 08:34:51','admin-id','2026-01-14 08:35:02',1),
('324249dc-432a-44b8-8191-cb1bfe2ad530','admin-id','Ton','Weight',1,'admin-id','2026-01-14 08:33:44','admin-id','2026-01-14 08:35:06',1),
('344eb4c8-48c4-475b-b74c-307a0e492622','admin-id','Pcs','Countable',1,'admin-id','2026-01-11 04:40:18','admin-id','2026-01-14 08:32:31',1),
('50d3582c-909a-4818-afd7-54a8db8c1a44','admin-id','Pack','Countable',1,'admin-id','2026-01-11 04:40:31','admin-id','2026-01-14 08:32:33',1),
('53640e3f-20b8-44a6-8872-5844630bfed0','admin-id','Gal','Volume',1,'admin-id','2026-01-14 08:34:28','admin-id','2026-01-14 08:35:16',1),
('61accd0f-ebd7-4c2c-9e33-ba5f92e091d1','admin-id','Dzn','Countable',1,'admin-id','2026-01-11 04:40:57','admin-id','2026-01-18 12:06:56',1),
('674e6bee-5066-415a-9f35-b6e72f978a08','admin-id','Yard','Length',1,'admin-id','2026-01-11 04:43:59','admin-id','2026-01-14 08:32:44',1),
('78a63632-6a35-49ab-8cac-4b5c0d4fb418','admin-id','Box','Countable',1,'admin-id','2026-01-11 04:40:52','admin-id','2026-01-14 08:32:46',1),
('9233b04b-3367-4205-9b3c-bb569e1bebb6','admin-id','Inch','Length',1,'admin-id','2026-01-14 08:34:34','admin-id','2026-01-14 08:35:21',1),
('a08ee30c-cb3d-467c-aff6-d347c74c9e8b','admin-id','Cm','Length',1,'admin-id','2026-01-14 08:34:39','admin-id','2026-01-14 08:35:25',1),
('abc985a3-68b1-4b98-825b-ebe79903d033','admin-id','Bottle','Countable',1,'admin-id','2026-01-14 08:33:58','admin-id','2026-01-14 08:35:29',1),
('c1ab2f8e-5030-40a4-85a3-569ad7cc6dd7','admin-id','Cage','Countable',1,'admin-id','2026-01-14 08:34:18','admin-id','2026-01-14 08:35:35',1),
('cdd3a6c9-d31b-4a41-8762-69700e2a1108','admin-id','Ctn','Countable',1,'admin-id','2026-01-11 04:40:23','admin-id','2026-01-14 08:32:47',1),
('f13c1fb3-3493-4640-9b13-02bd824b4977','admin-id','Gm','Weight',1,'admin-id','2026-01-14 08:33:32','admin-id','2026-01-14 08:35:38',1),
('f2fa8d7c-69d4-439d-9dea-66fba7aac17b','admin-id','Bag','Mass',1,'admin-id','2026-01-14 08:34:10','admin-id','2026-01-14 08:35:50',1),
('f5ccd3c1-fd1e-4f0e-93be-59dd878c881a','admin-id','Poly','Countable',1,'admin-id','2026-01-14 08:25:05','admin-id','2026-01-14 08:32:49',1),
('f5d78785-c08b-46b7-a77f-dcf1a8700dd0','admin-id','Crate','Mass',1,'admin-id','2026-01-14 08:33:25','admin-id','2026-01-14 08:35:46',1);
/*!40000 ALTER TABLE `tmib_iuofm` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmib_mtrsf`
--

DROP TABLE IF EXISTS `tmib_mtrsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmib_mtrsf` (
  `id` varchar(50) NOT NULL,
  `mtrsf_users` varchar(50) NOT NULL,
  `mtrsf_bsins` varchar(50) NOT NULL,
  `mtrsf_bsins_to` varchar(50) NOT NULL,
  `mtrsf_trnno` varchar(50) NOT NULL,
  `mtrsf_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mtrsf_refno` varchar(50) DEFAULT NULL,
  `mtrsf_trnte` varchar(100) DEFAULT NULL,
  `mtrsf_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mtrsf_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mtrsf_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mtrsf_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `mtrsf_isrcv` tinyint(1) NOT NULL DEFAULT 0,
  `mtrsf_rcusr` varchar(50) DEFAULT NULL,
  `mtrsf_rcdat` datetime DEFAULT NULL,
  `mtrsf_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mtrsf_crusr` varchar(50) NOT NULL,
  `mtrsf_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mtrsf_upusr` varchar(50) NOT NULL,
  `mtrsf_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mtrsf_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmib_mtrsf`
--

LOCK TABLES `tmib_mtrsf` WRITE;
/*!40000 ALTER TABLE `tmib_mtrsf` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmib_mtrsf` VALUES
('0d9af1be-dfbd-4e1e-b92c-eb5d9637e189','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','6dd0f9d0-840a-43ce-8f82-a60310521756','IT-300126-00001','2026-01-30 00:00:00','','',8500.000000,0.000000,8500.000000,1,0,'','2026-01-30 00:00:00',1,'admin-id','2026-01-30 03:32:35','admin-id','2026-01-30 03:32:35',1),
('2cd28473-8e12-4222-9d22-a7b981d235dc','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','6dd0f9d0-840a-43ce-8f82-a60310521756','IT-300126-00005','2026-01-30 00:00:00','','',5500.000000,0.000000,5500.000000,1,0,'','2026-01-30 00:00:00',1,'admin-id','2026-01-30 04:25:09','admin-id','2026-01-30 04:25:09',1),
('42dccf1f-1c32-4d8f-856d-36caf8a414b9','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','6dd0f9d0-840a-43ce-8f82-a60310521756','IT-300126-00002','2026-01-30 00:00:00','','',3750.000000,0.000000,3750.000000,1,0,'','2026-01-30 00:00:00',1,'admin-id','2026-01-30 04:16:15','admin-id','2026-01-30 04:16:15',1),
('9ddf27e1-87ce-4eda-96a7-5bca832984bc','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','6dd0f9d0-840a-43ce-8f82-a60310521756','IT-300126-00006','2026-01-30 00:00:00','','',850.000000,0.000000,850.000000,1,0,'','2026-01-30 00:00:00',1,'admin-id','2026-01-30 04:26:26','admin-id','2026-01-30 04:26:26',1),
('edad1143-07e5-4cdb-a2c4-d2e4a679ba17','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','6dd0f9d0-840a-43ce-8f82-a60310521756','IT-300126-00004','2026-01-30 00:00:00','','',11000.000000,0.000000,11000.000000,1,0,'','2026-01-30 00:00:00',1,'admin-id','2026-01-30 04:24:22','admin-id','2026-01-30 04:24:22',1),
('f5a4e363-8ee1-4e73-a942-8768a95018b5','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','0410da9c-2a16-43b3-b0b6-4015eeb245a8','IT-300126-00003','2026-01-30 00:00:00','','',9000.000000,0.000000,9000.000000,1,0,'','2026-01-30 00:00:00',1,'admin-id','2026-01-30 04:24:09','admin-id','2026-01-30 04:24:09',1);
/*!40000 ALTER TABLE `tmib_mtrsf` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_bking`
--

DROP TABLE IF EXISTS `tmpb_bking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_bking` (
  `id` varchar(50) NOT NULL,
  `bking_pmstr` varchar(50) NOT NULL,
  `bking_bitem` varchar(50) NOT NULL,
  `bking_items` varchar(50) NOT NULL,
  `bking_bkrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_bkqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_notes` varchar(50) DEFAULT NULL,
  `bking_cnqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_rcqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_pnqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `bking_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bking_crusr` varchar(50) NOT NULL,
  `bking_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bking_upusr` varchar(50) NOT NULL,
  `bking_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bking_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_bking`
--

LOCK TABLES `tmpb_bking` WRITE;
/*!40000 ALTER TABLE `tmpb_bking` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmpb_bking` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_cbkng`
--

DROP TABLE IF EXISTS `tmpb_cbkng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_cbkng` (
  `id` varchar(50) NOT NULL,
  `cbkng_mbkng` varchar(50) NOT NULL,
  `cbkng_bitem` varchar(50) NOT NULL,
  `cbkng_items` varchar(50) NOT NULL,
  `cbkng_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_notes` varchar(50) DEFAULT NULL,
  `cbkng_attrb` varchar(300) DEFAULT NULL,
  `cbkng_cnqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_rcqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_pnqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cbkng_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cbkng_crusr` varchar(50) NOT NULL,
  `cbkng_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cbkng_upusr` varchar(50) NOT NULL,
  `cbkng_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cbkng_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_cbkng`
--

LOCK TABLES `tmpb_cbkng` WRITE;
/*!40000 ALTER TABLE `tmpb_cbkng` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_cbkng` VALUES
('8bcc18b5-13bf-4eba-af4d-82f31b540951','3cc4bede-25d6-49df-9654-09d776618e0c','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,500.000000,55000.000000,0.000000,0.000000,5.000000,2750.000000,110.100000,57750.000000,'DO#123-123','{}',0.000000,215.000000,285.000000,1,'admin-id','2026-01-27 14:41:16','admin-id','2026-01-30 11:48:07',1),
('add96d29-899c-46da-9ac0-e6576d8b694f','2f7c3961-8ec8-44f8-acf2-36e38f848543','a5da4ada-2216-49a6-bfde-aa71f0de6bb8','38b496e9-6652-4324-8331-ba0ecb0cfeae',60.000000,20.000000,1200.000000,0.000000,0.000000,5.000000,60.000000,63.500000,1260.000000,'','{}',0.000000,0.000000,20.000000,1,'admin-id','2026-01-28 10:17:52','admin-id','2026-01-28 10:17:52',1);
/*!40000 ALTER TABLE `tmpb_cbkng` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_cinvc`
--

DROP TABLE IF EXISTS `tmpb_cinvc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_cinvc` (
  `id` varchar(50) NOT NULL,
  `cinvc_minvc` varchar(50) NOT NULL,
  `cinvc_bitem` varchar(50) NOT NULL,
  `cinvc_items` varchar(50) NOT NULL,
  `cinvc_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_notes` varchar(50) DEFAULT NULL,
  `cinvc_attrb` varchar(300) DEFAULT NULL,
  `cinvc_rtqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_slqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_ohqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `cinvc_actve` tinyint(1) NOT NULL DEFAULT 1,
  `cinvc_crusr` varchar(50) NOT NULL,
  `cinvc_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `cinvc_upusr` varchar(50) NOT NULL,
  `cinvc_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cinvc_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_cinvc`
--

LOCK TABLES `tmpb_cinvc` WRITE;
/*!40000 ALTER TABLE `tmpb_cinvc` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_cinvc` VALUES
('0305edc3-923a-4049-bbc8-60f747f1e4bb','f34b931f-65b6-40b1-99ab-1d75d8375ebd','fdfa97ae-9622-4548-bc27-4cf8a163cfa3','e45670a3-981c-47c2-bd6a-a02bd8c0d7b0',160.000000,25.000000,4000.000000,0.000000,0.000000,5.000000,200.000000,160.000000,4200.000000,'','{}',0.000000,0.000000,25.000000,1,'admin-id','2026-01-30 11:51:04','admin-id','2026-01-30 11:51:04',1),
('152150bf-ba66-4ad8-b556-1d208cb3f792','d5327b0e-4eb4-4d7e-afd5-62ef75ac6109','49637732-1033-454e-8690-e4162e763fdd','8873e069-eea6-4f9e-acf0-dd1cb658f9c8',18.000000,80.000000,1440.000000,0.000000,0.000000,10.000000,144.000000,18.000000,1584.000000,'','{}',0.000000,0.000000,80.000000,1,'admin-id','2026-01-30 12:16:33','admin-id','2026-01-30 12:16:33',1),
('1bc377e6-10df-405a-9b83-78b67431e938','d5327b0e-4eb4-4d7e-afd5-62ef75ac6109','854996eb-cabc-487b-a5bc-692bfffe2689','75b05c78-9b6b-42ba-aafa-e76e22f67722',28.000000,70.000000,1960.000000,0.000000,0.000000,7.500000,147.000000,28.000000,2107.000000,'','{}',0.000000,0.000000,70.000000,1,'admin-id','2026-01-30 12:16:33','admin-id','2026-01-30 12:16:33',1),
('568fb2f5-424b-4827-a642-83cb5c641b6a','fbaae972-c416-4742-9d62-0b136be59ca5','a5da4ada-2216-49a6-bfde-aa71f0de6bb8','38b496e9-6652-4324-8331-ba0ecb0cfeae',60.000000,50.000000,3000.000000,0.000000,0.000000,5.000000,150.000000,63.000000,3150.000000,'OC#666-7788','{\"Size\":\"5 Ltr\"}',0.000000,50.000000,0.000000,1,'admin-id','2026-01-27 16:36:13','admin-id','2026-01-30 04:13:14',1),
('76217258-3c3c-4b22-b7fe-5966d5f00d3e','0cc26927-006e-4fc3-b9a0-24a4037bd529','d0249c21-993f-40a7-9819-d05b046d8591','e2e70dc1-9814-400c-8774-2b6b186b79e5',180.000000,50.000000,9000.000000,0.000000,0.000000,5.000000,450.000000,180.000000,9450.000000,'OC#654-456','{}',0.000000,50.000000,0.000000,1,'admin-id','2026-01-27 16:34:05','admin-id','2026-01-30 04:26:26',1),
('7a96c50a-ebf6-4941-bf66-3db5e8e19b4c','f34b931f-65b6-40b1-99ab-1d75d8375ebd','f79040d1-8a63-4b4a-a515-16796fd56797','4dab149a-e220-4cd8-a061-7660ab0168bb',58.000000,150.000000,8700.000000,0.000000,0.000000,5.000000,435.000000,58.000000,9135.000000,'','{}',0.000000,0.000000,150.000000,1,'admin-id','2026-01-30 11:51:04','admin-id','2026-01-30 11:51:04',1),
('ae18984e-bf0b-496e-b691-923b26d7bb2a','11346302-585a-4496-86a6-edf32e373ffa','22bbdf6e-759b-4b46-a0a6-b5d2a8d7d383','dfe206f2-b3a3-4d6c-8b3c-7402582348eb',15.000000,250.000000,3750.000000,0.000000,0.000000,5.000000,187.500000,15.000000,3937.500000,'INV#665-555','{}',0.000000,250.000000,0.000000,1,'admin-id','2026-01-29 14:25:47','admin-id','2026-01-30 04:26:26',1),
('c5ee5d34-670f-47f5-97d0-753fb1f3d3f3','f34b931f-65b6-40b1-99ab-1d75d8375ebd','854996eb-cabc-487b-a5bc-692bfffe2689','75b05c78-9b6b-42ba-aafa-e76e22f67722',28.000000,15.000000,420.000000,0.000000,0.000000,7.500000,31.500000,28.000000,451.500000,'','{}',0.000000,0.000000,15.000000,1,'admin-id','2026-01-30 11:51:04','admin-id','2026-01-30 11:51:04',1),
('ff5a866c-c546-48c5-906a-3a0835492a82','21d9dc24-15b2-4baf-baba-2635e149065f','73a91ad4-50f1-4b8b-8a93-ad00e7829c8f','4b100c2e-68a6-467b-94b7-617a6c7b43dc',85.000000,10.000000,850.000000,0.000000,0.000000,7.500000,63.750000,85.000000,913.750000,'','{}',0.000000,10.000000,0.000000,1,'admin-id','2026-01-30 04:26:09','admin-id','2026-01-30 04:26:26',1);
/*!40000 ALTER TABLE `tmpb_cinvc` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_crcpt`
--

DROP TABLE IF EXISTS `tmpb_crcpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_crcpt` (
  `id` varchar(50) NOT NULL,
  `crcpt_mrcpt` varchar(50) NOT NULL,
  `crcpt_bitem` varchar(50) NOT NULL,
  `crcpt_items` varchar(50) NOT NULL,
  `crcpt_itrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_itqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_itamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_dspct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_vtpct` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_csrat` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_ntamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_notes` varchar(50) DEFAULT NULL,
  `crcpt_attrb` varchar(300) DEFAULT NULL,
  `crcpt_rtqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_slqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_ohqty` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `crcpt_cbkng` varchar(50) NOT NULL,
  `crcpt_actve` tinyint(1) NOT NULL DEFAULT 1,
  `crcpt_crusr` varchar(50) NOT NULL,
  `crcpt_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crcpt_upusr` varchar(50) NOT NULL,
  `crcpt_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `crcpt_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_crcpt`
--

LOCK TABLES `tmpb_crcpt` WRITE;
/*!40000 ALTER TABLE `tmpb_crcpt` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_crcpt` VALUES
('0f1de64b-740f-4b3f-8b0e-ead54e46d4a6','99091e42-9b11-48fc-b9e4-48bee519d3a2','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,50.000000,5500.000000,0.000000,0.000000,5.000000,275.000000,115.500000,5775.000000,'OC#-1','{}',0.000000,50.000000,0.000000,'8bcc18b5-13bf-4eba-af4d-82f31b540951',1,'admin-id','2026-01-27 14:42:12','admin-id','2026-01-30 04:26:26',1),
('20e07a84-156d-44b3-a107-9020f719bff8','ccce72a9-000e-42de-aa1f-63b12ba6e3d9','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,50.000000,5500.000000,0.000000,0.000000,5.000000,275.000000,111.000000,5775.000000,'OC#123-001','{}',0.000000,50.000000,0.000000,'8bcc18b5-13bf-4eba-af4d-82f31b540951',1,'admin-id','2026-01-27 15:11:19','admin-id','2026-01-30 04:15:03',1),
('c49e8d48-db93-486b-b2c1-9ddc28dbaec7','e9174829-2d14-4f5a-bd47-43f3b0309851','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,15.000000,1650.000000,0.000000,0.000000,5.000000,82.500000,115.500000,1732.500000,'DO#123-123','{}',0.000000,0.000000,15.000000,'8bcc18b5-13bf-4eba-af4d-82f31b540951',1,'admin-id','2026-01-30 11:48:07','admin-id','2026-01-30 11:48:07',1),
('cbdcede5-1100-4cbb-9eff-99de1526e263','84190535-abf7-4a36-af0f-e898197f680a','22064b47-6898-4661-9dc8-5329a542ae4a','24614ec4-8ab0-4b50-b3c7-9f154a124770',110.000000,100.000000,11000.000000,0.000000,0.000000,5.000000,550.000000,110.350000,11550.000000,'OC#123-002','{}',0.000000,100.000000,0.000000,'8bcc18b5-13bf-4eba-af4d-82f31b540951',1,'admin-id','2026-01-27 15:44:48','admin-id','2026-01-30 04:26:26',1);
/*!40000 ALTER TABLE `tmpb_crcpt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_expns`
--

DROP TABLE IF EXISTS `tmpb_expns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_expns` (
  `id` varchar(50) NOT NULL,
  `expns_users` varchar(50) NOT NULL,
  `expns_bsins` varchar(50) NOT NULL,
  `expns_cntct` varchar(50) NOT NULL,
  `expns_refid` varchar(50) NOT NULL,
  `expns_refno` varchar(50) NOT NULL,
  `expns_srcnm` varchar(50) NOT NULL,
  `expns_trdat` date NOT NULL DEFAULT current_timestamp(),
  `expns_inexc` tinyint(1) NOT NULL DEFAULT 1,
  `expns_notes` varchar(100) DEFAULT NULL,
  `expns_xpamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `expns_actve` tinyint(1) NOT NULL DEFAULT 1,
  `expns_crusr` varchar(50) NOT NULL,
  `expns_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `expns_upusr` varchar(50) NOT NULL,
  `expns_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expns_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_expns`
--

LOCK TABLES `tmpb_expns` WRITE;
/*!40000 ALTER TABLE `tmpb_expns` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_expns` VALUES
('0e368a86-a81e-41a8-9ea7-9e69e1f8bfd1','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','ccce72a9-000e-42de-aa1f-63b12ba6e3d9','PR-270126-00002','Purchase Receipt','2026-01-28',1,'',50.000000,1,'admin-id','2026-01-27 15:11:19','admin-id','2026-01-27 15:11:19',1),
('7954b4f5-2ef9-479b-b5f8-8c885678665f','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','2f7c3961-8ec8-44f8-acf2-36e38f848543','PB-280126-00001','Purchase Booking','2026-01-28',1,'',50.000000,1,'admin-id','2026-01-28 10:17:52','admin-id','2026-01-28 10:17:52',1),
('b57e7425-8a53-4b97-bf65-65087ded5d27','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','3cc4bede-25d6-49df-9654-09d776618e0c','PB-270126-00001','Purchase Booking','2026-01-28',1,'BT#123-123',50.000000,1,'admin-id','2026-01-27 14:41:16','admin-id','2026-01-27 14:41:16',1),
('b6f4f607-cec4-4f88-8a8a-bae63c92834f','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','6dd0f9d0-840a-43ce-8f82-a60310521756','bdaf74fc-e710-4095-8d1b-e09f4d761535','IT-300126-00001','Internal Transfer','2026-01-30',2,'',100.000000,1,'admin-id','2026-01-30 01:38:18','admin-id','2026-01-30 01:38:18',1),
('e09c7229-01d7-43f6-827f-fd0d02e7e665','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','84190535-abf7-4a36-af0f-e898197f680a','PR-270126-00003','Purchase Receipt','2026-01-28',1,'',35.000000,1,'admin-id','2026-01-27 15:44:48','admin-id','2026-01-27 15:44:48',1),
('e1107600-762d-4a16-813d-0cb1b0b1b081','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','2f7c3961-8ec8-44f8-acf2-36e38f848543','PB-280126-00001','Purchase Booking','2026-01-28',2,'',20.000000,1,'admin-id','2026-01-28 10:17:52','admin-id','2026-01-28 10:17:52',1);
/*!40000 ALTER TABLE `tmpb_expns` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_mbkng`
--

DROP TABLE IF EXISTS `tmpb_mbkng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_mbkng` (
  `id` varchar(50) NOT NULL,
  `mbkng_users` varchar(50) NOT NULL,
  `mbkng_bsins` varchar(50) NOT NULL,
  `mbkng_cntct` varchar(50) NOT NULL,
  `mbkng_trnno` varchar(50) NOT NULL,
  `mbkng_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mbkng_refno` varchar(50) DEFAULT NULL,
  `mbkng_trnte` varchar(100) DEFAULT NULL,
  `mbkng_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_cnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mbkng_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `mbkng_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mbkng_crusr` varchar(50) NOT NULL,
  `mbkng_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mbkng_upusr` varchar(50) NOT NULL,
  `mbkng_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mbkng_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_mbkng`
--

LOCK TABLES `tmpb_mbkng` WRITE;
/*!40000 ALTER TABLE `tmpb_mbkng` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_mbkng` VALUES
('2f7c3961-8ec8-44f8-acf2-36e38f848543','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','PB-280126-00001','2026-01-28 00:00:00','','',1200.000000,0.000000,60.000000,1,50.000000,20.000000,0.000000,1310.000000,1310.000000,1310.000000,0.000000,0.000000,1,1,0,0,0,1,'admin-id','2026-01-28 10:17:52','admin-id','2026-01-28 10:25:34',1),
('3cc4bede-25d6-49df-9654-09d776618e0c','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PB-270126-00001','2026-01-27 00:00:00','DO#123-123','',55000.000000,0.000000,2750.000000,1,50.000000,0.000000,0.000000,57800.000000,57800.000000,57800.000000,0.000000,0.000000,1,1,0,0,0,1,'admin-id','2026-01-27 14:41:16','admin-id','2026-01-28 10:25:37',1);
/*!40000 ALTER TABLE `tmpb_mbkng` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_minvc`
--

DROP TABLE IF EXISTS `tmpb_minvc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_minvc` (
  `id` varchar(50) NOT NULL,
  `minvc_users` varchar(50) NOT NULL,
  `minvc_bsins` varchar(50) NOT NULL,
  `minvc_cntct` varchar(50) NOT NULL,
  `minvc_trnno` varchar(50) NOT NULL,
  `minvc_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `minvc_refno` varchar(50) DEFAULT NULL,
  `minvc_trnte` varchar(100) DEFAULT NULL,
  `minvc_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_rtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `minvc_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `minvc_actve` tinyint(1) NOT NULL DEFAULT 1,
  `minvc_crusr` varchar(50) NOT NULL,
  `minvc_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `minvc_upusr` varchar(50) NOT NULL,
  `minvc_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `minvc_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_minvc`
--

LOCK TABLES `tmpb_minvc` WRITE;
/*!40000 ALTER TABLE `tmpb_minvc` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_minvc` VALUES
('0cc26927-006e-4fc3-b9a0-24a4037bd529','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','PI-270126-00001','2026-01-27 00:00:00','OC#654-456','',9000.000000,0.000000,450.000000,1,0.000000,0.000000,0.000000,9450.000000,9450.000000,9450.000000,0.000000,0.000000,2,1,0,0,0,1,'admin-id','2026-01-27 16:34:05','admin-id','2026-01-28 10:25:36',1),
('11346302-585a-4496-86a6-edf32e373ffa','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','PI-290126-00001','2026-01-29 00:00:00','INV#665-555','',3750.000000,0.000000,187.500000,1,0.000000,0.000000,0.000000,3937.500000,3937.500000,3500.000000,438.000000,0.000000,2,1,0,0,0,1,'admin-id','2026-01-29 14:25:47','admin-id','2026-01-29 14:25:47',1),
('21d9dc24-15b2-4baf-baba-2635e149065f','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PI-300126-00001','2026-01-30 00:00:00','','',850.000000,0.000000,63.750000,1,0.000000,0.000000,0.000000,913.750000,913.750000,0.000000,914.000000,0.000000,0,1,0,0,0,1,'admin-id','2026-01-30 04:26:09','admin-id','2026-01-30 04:26:09',1),
('d5327b0e-4eb4-4d7e-afd5-62ef75ac6109','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PI-300126-00003','2026-01-30 00:00:00','','',3400.000000,0.000000,291.000000,1,0.000000,0.000000,0.000000,3691.000000,3691.000000,3600.000000,91.000000,0.000000,2,1,0,0,0,1,'admin-id','2026-01-30 12:16:32','admin-id','2026-01-30 12:16:32',1),
('f34b931f-65b6-40b1-99ab-1d75d8375ebd','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','PI-300126-00002','2026-01-30 00:00:00','','',13120.000000,0.000000,666.500000,1,0.000000,0.000000,0.500000,13786.000000,13786.000000,13000.000000,786.000000,0.000000,2,1,0,0,0,1,'admin-id','2026-01-30 11:51:04','admin-id','2026-01-30 11:51:04',1),
('fbaae972-c416-4742-9d62-0b136be59ca5','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','PI-270126-00002','2026-01-27 00:00:00','OC#666-7788','',3000.000000,0.000000,150.000000,1,0.000000,0.000000,0.000000,3150.000000,3150.000000,3150.000000,0.000000,0.000000,2,1,0,0,0,1,'admin-id','2026-01-27 16:36:13','admin-id','2026-01-28 10:25:39',1);
/*!40000 ALTER TABLE `tmpb_minvc` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmpb_mrcpt`
--

DROP TABLE IF EXISTS `tmpb_mrcpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpb_mrcpt` (
  `id` varchar(50) NOT NULL,
  `mrcpt_users` varchar(50) NOT NULL,
  `mrcpt_bsins` varchar(50) NOT NULL,
  `mrcpt_cntct` varchar(50) NOT NULL,
  `mrcpt_trnno` varchar(50) NOT NULL,
  `mrcpt_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mrcpt_refno` varchar(50) DEFAULT NULL,
  `mrcpt_trnte` varchar(100) DEFAULT NULL,
  `mrcpt_odamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_dsamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_vtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_vatpy` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_incst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_excst` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_rnamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_ttamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_pyamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_pdamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_duamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_rtamt` decimal(20,6) NOT NULL DEFAULT 0.000000,
  `mrcpt_ispad` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_ispst` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_iscls` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_vatcl` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_hscnl` tinyint(1) NOT NULL DEFAULT 0,
  `mrcpt_actve` tinyint(1) NOT NULL DEFAULT 1,
  `mrcpt_crusr` varchar(50) NOT NULL,
  `mrcpt_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `mrcpt_upusr` varchar(50) NOT NULL,
  `mrcpt_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mrcpt_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpb_mrcpt`
--

LOCK TABLES `tmpb_mrcpt` WRITE;
/*!40000 ALTER TABLE `tmpb_mrcpt` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmpb_mrcpt` VALUES
('84190535-abf7-4a36-af0f-e898197f680a','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PR-270126-00003','2026-01-27 00:00:00','OC#123-002','',11000.000000,0.000000,550.000000,1,35.000000,0.000000,0.000000,11585.000000,11585.000000,11585.000000,0.000000,0.000000,1,1,0,0,0,1,'admin-id','2026-01-27 15:44:48','admin-id','2026-01-27 15:44:48',1),
('99091e42-9b11-48fc-b9e4-48bee519d3a2','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PR-270126-00001','2026-01-27 00:00:00','OC#-1','',5500.000000,0.000000,275.000000,1,0.000000,0.000000,0.000000,5775.000000,5775.000000,5775.000000,0.000000,0.000000,1,1,0,0,0,1,'admin-id','2026-01-27 14:42:12','admin-id','2026-01-27 14:42:12',1),
('ccce72a9-000e-42de-aa1f-63b12ba6e3d9','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PR-270126-00002','2026-01-27 00:00:00','OC#123-001','',5500.000000,0.000000,275.000000,1,50.000000,0.000000,0.000000,5825.000000,5825.000000,5825.000000,0.000000,0.000000,1,1,0,0,0,1,'admin-id','2026-01-27 15:11:19','admin-id','2026-01-27 15:11:19',1),
('e9174829-2d14-4f5a-bd47-43f3b0309851','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','PR-300126-00001','2026-01-30 00:00:00','','',1650.000000,0.000000,82.500000,1,0.000000,0.000000,0.000000,1732.500000,1732.500000,1732.500000,0.000000,0.000000,1,1,0,0,0,1,'admin-id','2026-01-30 11:48:07','admin-id','2026-01-30 11:48:07',1);
/*!40000 ALTER TABLE `tmpb_mrcpt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_bsins`
--

DROP TABLE IF EXISTS `tmsb_bsins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_bsins` (
  `id` varchar(50) NOT NULL,
  `bsins_users` varchar(255) NOT NULL,
  `bsins_bname` varchar(255) NOT NULL,
  `bsins_addrs` varchar(255) DEFAULT NULL,
  `bsins_email` varchar(255) DEFAULT NULL,
  `bsins_cntct` varchar(255) DEFAULT NULL,
  `bsins_image` varchar(255) DEFAULT NULL,
  `bsins_binno` varchar(255) DEFAULT NULL,
  `bsins_btags` varchar(255) DEFAULT NULL,
  `bsins_cntry` varchar(50) DEFAULT NULL,
  `bsins_bstyp` varchar(50) DEFAULT NULL,
  `bsins_tstrn` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_prtrn` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_sltrn` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_stdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bsins_pbviw` tinyint(1) NOT NULL DEFAULT 0,
  `bsins_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bsins_crusr` varchar(50) NOT NULL,
  `bsins_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bsins_upusr` varchar(50) NOT NULL,
  `bsins_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bsins_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_bsins_users_bsins_bname` (`bsins_users`,`bsins_bname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_bsins`
--

LOCK TABLES `tmsb_bsins` WRITE;
/*!40000 ALTER TABLE `tmsb_bsins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_bsins` VALUES
('business1','user1','Green Mart – Uttara','Sector 10, Uttara, Dhaka','admin@sgd.com','01722688266',NULL,'GT-9872-6871-5555','Retail','Bangladesh','Store',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:38',6),
('business2','user1','White Mart – Dhanmondi','Road 27, Dhanmondi, Dhaka','admin@sgd.com','01722688266',NULL,'CT2025-0978-22364','Retail','Bangladesh','Store',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:40',3),
('business3','user1','Red Mart - Badda','Uttar Badda, Dhaka','admin@sgd.com','01722688266',NULL,'CT2025-0978-22364','Retail','Bangladesh','Store',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:42',3),
('business4','user1','Central Distribution Warehouse','Uttar Badda, Dhaka','admin@sgd.com','01722688266',NULL,'CT2025-0978-22364','Retail','Bangladesh','Warehouse',1,1,1,'2026-01-31 00:00:00',0,1,'user1','2026-01-31 08:03:14','user1','2026-01-31 09:28:43',7);
/*!40000 ALTER TABLE `tmsb_bsins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_crgrn`
--

DROP TABLE IF EXISTS `tmsb_crgrn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_crgrn` (
  `id` varchar(50) NOT NULL,
  `crgrn_users` varchar(50) NOT NULL,
  `crgrn_bsins` varchar(50) NOT NULL,
  `crgrn_tblnm` varchar(50) NOT NULL,
  `crgrn_tbltx` varchar(50) DEFAULT NULL,
  `crgrn_refno` varchar(50) DEFAULT NULL,
  `crgrn_dbgrn` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `crgrn_crgrn` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `crgrn_isdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crgrn_xpdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crgrn_actve` tinyint(1) NOT NULL DEFAULT 1,
  `crgrn_crusr` varchar(50) NOT NULL,
  `crgrn_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `crgrn_upusr` varchar(50) NOT NULL,
  `crgrn_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `crgrn_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_crgrn`
--

LOCK TABLES `tmsb_crgrn` WRITE;
/*!40000 ALTER TABLE `tmsb_crgrn` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_crgrn` VALUES
('e0bdba06-a4d9-4010-90dc-ab4d433cb413','u1','b1','tmsb_crgrn','Registration','My Shop BD',0.000000,1000.000000,'2026-01-31 08:03:14','2026-01-31 08:03:14',1,'u1','2026-01-31 08:03:14','u1','2026-01-31 08:04:27',1);
/*!40000 ALTER TABLE `tmsb_crgrn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmsb_users`
--

DROP TABLE IF EXISTS `tmsb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmsb_users` (
  `id` varchar(50) NOT NULL,
  `users_email` varchar(50) NOT NULL,
  `users_pswrd` varchar(50) NOT NULL,
  `users_recky` varchar(50) NOT NULL,
  `users_oname` varchar(255) NOT NULL,
  `users_cntct` varchar(50) DEFAULT NULL,
  `users_bsins` varchar(50) DEFAULT NULL,
  `users_drole` varchar(50) DEFAULT NULL,
  `users_users` varchar(50) DEFAULT NULL,
  `users_stats` int(11) NOT NULL DEFAULT 0,
  `users_regno` varchar(50) DEFAULT NULL,
  `users_regdt` datetime NOT NULL DEFAULT current_timestamp(),
  `users_ltokn` varchar(50) DEFAULT NULL,
  `users_lstgn` datetime NOT NULL DEFAULT current_timestamp(),
  `users_lstpd` datetime NOT NULL DEFAULT current_timestamp(),
  `users_wctxt` varchar(100) DEFAULT NULL,
  `users_notes` varchar(100) DEFAULT NULL,
  `users_nofcr` decimal(16,2) NOT NULL DEFAULT 0.00,
  `users_isrgs` tinyint(1) NOT NULL DEFAULT 1,
  `users_actve` tinyint(1) NOT NULL DEFAULT 1,
  `users_crusr` varchar(50) NOT NULL,
  `users_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `users_upusr` varchar(50) NOT NULL,
  `users_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `users_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_email` (`users_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmsb_users`
--

LOCK TABLES `tmsb_users` WRITE;
/*!40000 ALTER TABLE `tmsb_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmsb_users` VALUES
('user1','admin@sgd.com','password','recover','Admin','01722688266','business1','Admin','user1',0,'Standard','2026-01-31 08:03:14',NULL,'2026-01-31 08:03:14','2026-01-31 09:43:39','Welcome Note','User Note',1000.00,1,1,'u1','2026-01-31 08:03:14','user1','2026-01-31 09:43:48',5),
('user2','user@sgd.com','password','recover','Common User','01722688266','business1','Admin','user1',0,'Standard','2026-01-31 09:29:44',NULL,'2026-01-31 09:29:44','2026-01-31 09:29:44','Welcome Note','User Note',0.00,0,1,'user1','2026-01-31 09:29:44','user1','2026-01-31 09:35:42',1);
/*!40000 ALTER TABLE `tmsb_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_bacts`
--

DROP TABLE IF EXISTS `tmtb_bacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_bacts` (
  `id` varchar(50) NOT NULL,
  `bacts_users` varchar(50) NOT NULL,
  `bacts_bankn` varchar(100) NOT NULL,
  `bacts_brnch` varchar(100) DEFAULT NULL,
  `bacts_routn` varchar(50) DEFAULT NULL,
  `bacts_acnam` varchar(100) DEFAULT NULL,
  `bacts_acnum` varchar(100) DEFAULT NULL,
  `bacts_notes` varchar(300) DEFAULT NULL,
  `bacts_opdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bacts_crbln` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `bacts_isdef` tinyint(1) NOT NULL DEFAULT 0,
  `bacts_actve` tinyint(1) NOT NULL DEFAULT 1,
  `bacts_crusr` varchar(50) NOT NULL,
  `bacts_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `bacts_upusr` varchar(50) NOT NULL,
  `bacts_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bacts_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_bacts`
--

LOCK TABLES `tmtb_bacts` WRITE;
/*!40000 ALTER TABLE `tmtb_bacts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_bacts` VALUES
('14bc4749-859b-46aa-aa67-29b926f88083','admin-id','Brac Bank PLC','Gulshan 2','123456','Sand Grain Digital','15000003454545','Deposit account','2026-01-09 00:00:00',5000.000000,0,0,'admin-id','2026-01-09 17:37:49','admin-id','2026-01-17 06:40:27',3),
('c306af10-f4c2-4ee8-8593-85de14c35b76','admin-id','Cash Account','Cash Account','0','Cash Account','123456','Cash Account','2026-01-09 00:00:00',23465.000000,1,1,'4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-09 12:06:49','4a0149be-7eb1-4e01-b3d2-b372ad335609','2026-01-17 06:43:49',1);
/*!40000 ALTER TABLE `tmtb_bacts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_ledgr`
--

DROP TABLE IF EXISTS `tmtb_ledgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_ledgr` (
  `id` varchar(50) NOT NULL,
  `ledgr_users` varchar(50) NOT NULL,
  `ledgr_bsins` varchar(50) NOT NULL,
  `ledgr_trhed` varchar(50) NOT NULL,
  `ledgr_cntct` varchar(50) NOT NULL,
  `ledgr_bacts` varchar(50) NOT NULL,
  `ledgr_pymod` varchar(50) NOT NULL,
  `ledgr_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ledgr_refno` varchar(50) NOT NULL,
  `ledgr_notes` varchar(100) DEFAULT NULL,
  `ledgr_dbamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `ledgr_cramt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `ledgr_crusr` varchar(50) NOT NULL,
  `ledgr_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `ledgr_upusr` varchar(50) NOT NULL,
  `ledgr_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ledgr_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_ledgr`
--

LOCK TABLES `tmtb_ledgr` WRITE;
/*!40000 ALTER TABLE `tmtb_ledgr` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_ledgr` VALUES
('322544db-ccf2-4326-94ea-c92325654f99','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z901','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-10 00:00:00','rent-5656','',1500.000000,0.000000,'admin-id','2026-01-10 08:17:42','admin-id','2026-01-10 08:17:42',1),
('3ddc69c4-c35d-4131-bf89-6af78de59c4f','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z701','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-17 00:00:00','#Cash Excess','',0.000000,365.000000,'admin-id','2026-01-17 06:39:45','admin-id','2026-01-17 06:39:45',1),
('57635f84-7cae-4a10-8927-cd34447800de','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z904','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-10 00:00:00','nov','',500.000000,0.000000,'admin-id','2026-01-10 08:19:11','admin-id','2026-01-10 08:19:11',1),
('5bb72d2a-7ef7-42c3-a12d-17ea7e874344','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z702','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-10 00:00:00','cash investment','',0.000000,25000.000000,'admin-id','2026-01-10 08:16:12','admin-id','2026-01-10 08:16:12',1),
('665b8fac-564b-470a-a922-4c484bfe1474','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z602','internal','14bc4749-859b-46aa-aa67-29b926f88083','Bank','2026-01-10 00:00:00','transfer','',0.000000,5000.000000,'admin-id','2026-01-10 08:16:47','admin-id','2026-01-10 08:16:47',1),
('6bf954fd-fea2-4898-9821-48874ac98e4d','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z903','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','MFS','2026-01-10 00:00:00','nov','',500.000000,0.000000,'admin-id','2026-01-10 08:18:22','admin-id','2026-01-10 08:18:22',1),
('8cddba78-957f-4745-b9fd-e5d2381222f0','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z1002','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Cash','2026-01-17 00:00:00','scap sales','',0.000000,5600.000000,'admin-id','2026-01-17 06:43:49','admin-id','2026-01-17 06:43:49',1),
('efaade64-7c50-4fe7-b1d3-f033622e800d','admin-id','0410da9c-2a16-43b3-b0b6-4015eeb245a8','Z601','internal','c306af10-f4c2-4ee8-8593-85de14c35b76','Bank','2026-01-10 00:00:00','transfer','',5000.000000,0.000000,'admin-id','2026-01-10 08:16:47','admin-id','2026-01-10 08:16:47',1);
/*!40000 ALTER TABLE `tmtb_ledgr` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_paybl`
--

DROP TABLE IF EXISTS `tmtb_paybl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_paybl` (
  `id` varchar(50) NOT NULL,
  `paybl_users` varchar(50) NOT NULL,
  `paybl_bsins` varchar(50) NOT NULL,
  `paybl_cntct` varchar(50) NOT NULL,
  `paybl_pymod` varchar(50) NOT NULL,
  `paybl_refid` varchar(50) NOT NULL,
  `paybl_refno` varchar(50) NOT NULL,
  `paybl_srcnm` varchar(50) NOT NULL,
  `paybl_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `paybl_descr` varchar(100) DEFAULT NULL,
  `paybl_notes` varchar(50) NOT NULL,
  `paybl_dbamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `paybl_cramt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `paybl_crusr` varchar(50) NOT NULL,
  `paybl_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `paybl_upusr` varchar(50) NOT NULL,
  `paybl_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `paybl_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_paybl`
--

LOCK TABLES `tmtb_paybl` WRITE;
/*!40000 ALTER TABLE `tmtb_paybl` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_paybl` VALUES
('0324407c-640b-4288-ac99-14e92d836a81','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Payment','99091e42-9b11-48fc-b9e4-48bee519d3a2','PR-270126-00001','Purchase Receipt','2026-01-27 00:00:00','Supplier Payment','Payment',5775.000000,0.000000,'admin-id','2026-01-27 14:42:12','admin-id','2026-01-27 14:42:12',1),
('063066b2-b8a7-445f-835c-ca08ad62d98e','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','Cash','fbaae972-c416-4742-9d62-0b136be59ca5','PI-270126-00002','Purchase Booking','2026-01-27 00:00:00','','Payment',3000.000000,0.000000,'admin-id','2026-01-27 16:36:13','admin-id','2026-01-27 16:36:13',1),
('166e3410-e58e-4cba-9f8e-f73a50349113','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Cash','3cc4bede-25d6-49df-9654-09d776618e0c','PB-270126-00001','Purchase Booking','2026-01-28 00:00:00','','Payment',2800.000000,0.000000,'admin-id','2026-01-28 10:25:37','admin-id','2026-01-28 10:25:37',1),
('2a0a0038-e7d0-4120-91db-0e1172792cf0','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Cash','0cc26927-006e-4fc3-b9a0-24a4037bd529','PI-270126-00001','Purchase Booking','2026-01-28 00:00:00','','Payment',450.000000,0.000000,'admin-id','2026-01-28 10:25:36','admin-id','2026-01-28 10:25:36',1),
('2abf96a5-4fbf-4c3f-b4bc-2869c1dc9abc','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','Cash','2f7c3961-8ec8-44f8-acf2-36e38f848543','PB-280126-00001','Purchase Booking','2026-01-28 00:00:00','','Payment',310.000000,0.000000,'admin-id','2026-01-28 10:25:34','admin-id','2026-01-28 10:25:34',1),
('364c2c97-654f-45c0-a9cb-a8ecbdbe2007','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','3cc4bede-25d6-49df-9654-09d776618e0c','PB-270126-00001','Purchase Booking','2026-01-27 00:00:00','Supplier Goods','Products',0.000000,57800.000000,'admin-id','2026-01-27 14:41:16','admin-id','2026-01-27 14:41:16',1),
('414c97c4-2e86-4f94-a2e9-c76d166f333e','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','84190535-abf7-4a36-af0f-e898197f680a','PR-270126-00003','Purchase Receipt','2026-01-27 00:00:00','Supplier Goods','Products',0.000000,11585.000000,'admin-id','2026-01-27 15:44:48','admin-id','2026-01-27 15:44:48',1),
('53474606-ca12-472b-b9ab-b9e135e15ad7','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','d5327b0e-4eb4-4d7e-afd5-62ef75ac6109','PI-300126-00003','Purchase Booking','2026-01-30 00:00:00','Supplier Goods','Products',0.000000,3691.000000,'admin-id','2026-01-30 12:16:33','admin-id','2026-01-30 12:16:33',1),
('57c7b4fd-f16a-4064-ae05-d2def8929aa6','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Cash','f34b931f-65b6-40b1-99ab-1d75d8375ebd','PI-300126-00002','Purchase Booking','2026-01-30 00:00:00','','Payment',13000.000000,0.000000,'admin-id','2026-01-30 11:51:04','admin-id','2026-01-30 11:51:04',1),
('60ac93d7-d64c-4852-8c95-e90dcff00c7c','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Payment','84190535-abf7-4a36-af0f-e898197f680a','PR-270126-00003','Purchase Receipt','2026-01-27 00:00:00','Supplier Payment','Payment',11585.000000,0.000000,'admin-id','2026-01-27 15:44:48','admin-id','2026-01-27 15:44:48',1),
('6128741b-83b3-4eec-aa9f-2ddc40d26bb4','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','e9174829-2d14-4f5a-bd47-43f3b0309851','PR-300126-00001','Purchase Receipt','2026-01-30 00:00:00','Supplier Goods','Products',0.000000,1732.500000,'admin-id','2026-01-30 11:48:07','admin-id','2026-01-30 11:48:07',1),
('657080ec-3c28-42a3-a3bd-8b9879f09ff4','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','ccce72a9-000e-42de-aa1f-63b12ba6e3d9','PR-270126-00002','Purchase Receipt','2026-01-27 00:00:00','Supplier Goods','Products',0.000000,5825.000000,'admin-id','2026-01-27 15:11:19','admin-id','2026-01-27 15:11:19',1),
('668edded-1b9d-495a-ad91-0ec8d97df97d','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Cash','11346302-585a-4496-86a6-edf32e373ffa','PI-290126-00001','Purchase Booking','2026-01-29 00:00:00','','Payment',3500.000000,0.000000,'admin-id','2026-01-29 14:25:47','admin-id','2026-01-29 14:25:47',1),
('6a6b0689-97ce-4b0e-8818-56ce4ccb89ac','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','99091e42-9b11-48fc-b9e4-48bee519d3a2','PR-270126-00001','Purchase Receipt','2026-01-27 00:00:00','Supplier Goods','Products',0.000000,5775.000000,'admin-id','2026-01-27 14:42:12','admin-id','2026-01-27 14:42:12',1),
('81794a58-f378-48b1-a351-fa171968d415','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Inventory','21d9dc24-15b2-4baf-baba-2635e149065f','PI-300126-00001','Purchase Booking','2026-01-30 00:00:00','Supplier Goods','Products',0.000000,913.750000,'admin-id','2026-01-30 04:26:09','admin-id','2026-01-30 04:26:09',1),
('89f6af3a-1f65-4435-8a09-5965268c53ce','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Bank','3cc4bede-25d6-49df-9654-09d776618e0c','PB-270126-00001','Purchase Booking','2026-01-28 00:00:00','BT#456-123','Payment',5000.000000,0.000000,'admin-id','2026-01-28 08:07:13','admin-id','2026-01-28 08:07:13',1),
('8bdd3bed-5c1c-43d2-a05c-1d62381515bd','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Inventory','f34b931f-65b6-40b1-99ab-1d75d8375ebd','PI-300126-00002','Purchase Booking','2026-01-30 00:00:00','Supplier Goods','Products',0.000000,13786.000000,'admin-id','2026-01-30 11:51:04','admin-id','2026-01-30 11:51:04',1),
('8fe7c9e0-b0ff-4113-94b7-895dcc655fbe','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','Inventory','fbaae972-c416-4742-9d62-0b136be59ca5','PI-270126-00002','Purchase Booking','2026-01-27 00:00:00','Supplier Goods','Products',0.000000,3150.000000,'admin-id','2026-01-27 16:36:13','admin-id','2026-01-27 16:36:13',1),
('9d4d635a-bfdb-4b5d-b2c6-8bef1b7b6db3','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Cash','0cc26927-006e-4fc3-b9a0-24a4037bd529','PI-270126-00001','Purchase Booking','2026-01-27 00:00:00','','Payment',9000.000000,0.000000,'admin-id','2026-01-27 16:34:05','admin-id','2026-01-27 16:34:05',1),
('a0b8ee3f-09d0-4f4c-8655-ab27da2331ee','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Bank','3cc4bede-25d6-49df-9654-09d776618e0c','PB-270126-00001','Purchase Booking','2026-01-27 00:00:00','BT#1234-1234','Payment',50000.000000,0.000000,'admin-id','2026-01-27 14:41:16','admin-id','2026-01-27 14:41:16',1),
('a1c0ea99-add1-4748-81dc-1cd2e7e20b66','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Inventory','0cc26927-006e-4fc3-b9a0-24a4037bd529','PI-270126-00001','Purchase Booking','2026-01-27 00:00:00','Supplier Goods','Products',0.000000,9450.000000,'admin-id','2026-01-27 16:34:05','admin-id','2026-01-27 16:34:05',1),
('b14e6956-dbb0-4951-9e53-a57ccd957eae','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','Cash','2f7c3961-8ec8-44f8-acf2-36e38f848543','PB-280126-00001','Purchase Booking','2026-01-28 00:00:00','','Payment',1000.000000,0.000000,'admin-id','2026-01-28 10:17:52','admin-id','2026-01-28 10:17:52',1),
('b92a45d0-5434-401f-b238-52144aa36732','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','Cash','fbaae972-c416-4742-9d62-0b136be59ca5','PI-270126-00002','Purchase Booking','2026-01-28 00:00:00','','Payment',150.000000,0.000000,'admin-id','2026-01-28 10:25:39','admin-id','2026-01-28 10:25:39',1),
('c570dd48-3179-4745-9aa0-d5978def26cb','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Payment','ccce72a9-000e-42de-aa1f-63b12ba6e3d9','PR-270126-00002','Purchase Receipt','2026-01-27 00:00:00','Supplier Payment','Payment',5825.000000,0.000000,'admin-id','2026-01-27 15:11:19','admin-id','2026-01-27 15:11:19',1),
('ce403c8c-569c-4068-aaa1-243ac6e84948','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Cash','d5327b0e-4eb4-4d7e-afd5-62ef75ac6109','PI-300126-00003','Purchase Booking','2026-01-30 00:00:00','','Payment',3600.000000,0.000000,'admin-id','2026-01-30 12:16:33','admin-id','2026-01-30 12:16:33',1),
('e419be64-ac9f-4e3f-a48c-5a4361d2ab3e','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','639611f4-97e5-4589-904e-190ef11f7f4e','Inventory','2f7c3961-8ec8-44f8-acf2-36e38f848543','PB-280126-00001','Purchase Booking','2026-01-28 00:00:00','Supplier Goods','Products',0.000000,1310.000000,'admin-id','2026-01-28 10:17:52','admin-id','2026-01-28 10:17:52',1),
('f30deb98-a581-4768-b384-74ece7f211ca','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','08eb3501-fcd0-4d99-84c3-ce5309bfe613','Payment','e9174829-2d14-4f5a-bd47-43f3b0309851','PR-300126-00001','Purchase Receipt','2026-01-30 00:00:00','Supplier Payment','Payment',1732.500000,0.000000,'admin-id','2026-01-30 11:48:07','admin-id','2026-01-30 11:48:07',1),
('f9f3cbd1-9f63-43bd-8f9c-5de029522c8c','admin-id','3881b053-9509-49db-835a-3f8dd8976cda','267bb3aa-9177-43d2-8d8b-e0137578cf98','Inventory','11346302-585a-4496-86a6-edf32e373ffa','PI-290126-00001','Purchase Booking','2026-01-29 00:00:00','Supplier Goods','Products',0.000000,3937.500000,'admin-id','2026-01-29 14:25:47','admin-id','2026-01-29 14:25:47',1);
/*!40000 ALTER TABLE `tmtb_paybl` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_rcvpy`
--

DROP TABLE IF EXISTS `tmtb_rcvpy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_rcvpy` (
  `id` varchar(50) NOT NULL,
  `rcvpy_users` varchar(50) NOT NULL,
  `rcvpy_bsins` varchar(50) NOT NULL,
  `rcvpy_cntct` varchar(50) NOT NULL,
  `rcvpy_pymod` varchar(50) NOT NULL,
  `rcvpy_refid` varchar(50) NOT NULL,
  `rcvpy_refno` varchar(50) NOT NULL,
  `rcvpy_srcnm` varchar(50) NOT NULL,
  `rcvpy_trdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rcvpy_notes` varchar(100) DEFAULT NULL,
  `rcvpy_pyamt` decimal(18,6) NOT NULL DEFAULT 0.000000,
  `rcvpy_crusr` varchar(50) NOT NULL,
  `rcvpy_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `rcvpy_upusr` varchar(50) NOT NULL,
  `rcvpy_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rcvpy_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_rcvpy`
--

LOCK TABLES `tmtb_rcvpy` WRITE;
/*!40000 ALTER TABLE `tmtb_rcvpy` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmtb_rcvpy` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmtb_trhed`
--

DROP TABLE IF EXISTS `tmtb_trhed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmtb_trhed` (
  `id` varchar(50) NOT NULL,
  `trhed_users` varchar(50) NOT NULL,
  `trhed_hednm` varchar(100) NOT NULL,
  `trhed_grpnm` varchar(100) NOT NULL,
  `trhed_grtyp` varchar(100) NOT NULL,
  `trhed_cntyp` varchar(100) NOT NULL,
  `trhed_actve` tinyint(1) NOT NULL DEFAULT 1,
  `trhed_crusr` varchar(50) NOT NULL,
  `trhed_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `trhed_upusr` varchar(50) NOT NULL,
  `trhed_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trhed_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmtb_trhed`
--

LOCK TABLES `tmtb_trhed` WRITE;
/*!40000 ALTER TABLE `tmtb_trhed` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmtb_trhed` VALUES
('Z1001','admin-id','Asset Purchase (-)','Asset','Out','Internal',1,'admin-id','2026-01-10 08:06:31','admin-id','2026-01-11 12:30:08',1),
('Z1002','admin-id','Asset Sale (+)','Asset','In','Internal',1,'admin-id','2026-01-10 08:06:31','admin-id','2026-01-28 06:26:47',1),
('Z101','admin-id','Sales Booking (+)','Sales','In','Customer',1,'admin-id','2026-01-10 08:07:18','admin-id','2026-01-10 08:07:18',1),
('Z102','admin-id','Sales Invoice (+)','Sales','In','Customer',1,'admin-id','2026-01-10 08:07:18','admin-id','2026-01-10 08:07:18',1),
('Z103','admin-id','Sales Order (+)','Sales','In','Customer',1,'admin-id','2026-01-10 08:07:18','admin-id','2026-01-10 08:07:18',1),
('Z104','admin-id','Sales Return (-)','Sales','Out','Customer',1,'admin-id','2026-01-10 08:07:18','admin-id','2026-01-10 08:07:18',1),
('Z105','admin-id','Sales Expense (-)','Sales','Out','Internal',1,'admin-id','2026-01-10 08:07:18','admin-id','2026-01-10 08:07:18',1),
('Z1101','admin-id','VAT Payment (-)','VAT','Out','Internal',1,'admin-id','2026-01-10 08:06:25','admin-id','2026-01-10 08:06:25',1),
('Z1102','admin-id','VAT Collection (+)','VAT','In','Internal',1,'admin-id','2026-01-10 08:06:25','admin-id','2026-01-10 08:06:25',1),
('Z1201','admin-id','Tax Payment (-)','Tax','Out','Internal',1,'admin-id','2026-01-10 08:06:18','admin-id','2026-01-10 08:06:18',1),
('Z1202','admin-id','Tax Receipt (+)','Tax','In','Internal',1,'admin-id','2026-01-10 08:06:18','admin-id','2026-01-10 08:06:18',1),
('Z1301','admin-id','Salary Payment (-)','HR','Out','Internal',1,'admin-id','2026-01-10 08:06:09','admin-id','2026-01-10 08:06:09',1),
('Z1302','admin-id','Salary Advance Payment (-)','HR','Out','Internal',1,'admin-id','2026-01-10 08:06:09','admin-id','2026-01-10 08:06:09',1),
('Z1303','admin-id','Salary Deduction (+)','HR','In','Internal',1,'admin-id','2026-01-10 08:06:09','admin-id','2026-01-10 08:06:09',1),
('Z1304','admin-id','Salary Advance Deduction (+)','HR','In','Internal',1,'admin-id','2026-01-10 08:06:09','admin-id','2026-01-10 08:06:09',1),
('Z201','admin-id','Purchase Booking (-)','Purchase','Out','Supplier',1,'admin-id','2026-01-10 08:07:11','admin-id','2026-01-10 08:07:11',1),
('Z202','admin-id','Purchase Invoice (-)','Purchase','Out','Supplier',1,'admin-id','2026-01-10 08:07:11','admin-id','2026-01-10 08:07:11',1),
('Z203','admin-id','Purchase Order (-)','Purchase','Out','Supplier',1,'admin-id','2026-01-10 08:07:11','admin-id','2026-01-10 08:07:11',1),
('Z204','admin-id','Purchase Return (+)','Purchase','In','Supplier',1,'admin-id','2026-01-10 08:07:11','admin-id','2026-01-10 08:07:11',1),
('Z205','admin-id','Purchase Expense (-)','Purchase','Out','Internal',1,'admin-id','2026-01-10 08:07:11','admin-id','2026-01-10 08:07:11',1),
('Z501','admin-id','Stock Out (-)','Inventory','Out','Internal',1,'admin-id','2026-01-10 08:07:05','admin-id','2026-01-10 08:07:05',1),
('Z502','admin-id','Stock In (+)','Inventory','In','Internal',1,'admin-id','2026-01-10 08:07:05','admin-id','2026-01-10 08:07:05',1),
('Z601','admin-id','Transfer Out (-)','Transfer','Out','Internal',1,'admin-id','2026-01-10 08:06:58','admin-id','2026-01-10 08:06:58',1),
('Z602','admin-id','Transfer In (+)','Transfer','In','Internal',1,'admin-id','2026-01-10 08:06:58','admin-id','2026-01-10 08:06:58',1),
('Z701','admin-id','Gain (+)','Income','In','Internal',1,'admin-id','2026-01-10 08:06:52','admin-id','2026-01-10 08:06:52',1),
('Z702','admin-id','Investment (+)','Income','In','Internal',1,'admin-id','2026-01-10 08:06:52','admin-id','2026-01-10 08:06:52',1),
('Z703','admin-id','Bank Profit (+)','Income','In','Internal',1,'admin-id','2026-01-10 08:06:52','admin-id','2026-01-10 08:06:52',1),
('Z704','admin-id','Bank Loan Received (+)','Income','In','Internal',1,'admin-id','2026-01-10 08:06:52','admin-id','2026-01-10 08:06:52',1),
('Z705','admin-id','Other Income (+)','Income','In','Internal',1,'admin-id','2026-01-10 08:06:52','admin-id','2026-01-10 08:06:52',1),
('Z801','admin-id','Loss (-)','Expenditure','Out','Internal',1,'admin-id','2026-01-10 08:06:45','admin-id','2026-01-11 12:34:15',1),
('Z802','admin-id','Withdrawal (-)','Expenditure','Out','Internal',1,'admin-id','2026-01-10 08:06:45','admin-id','2026-01-10 08:06:45',1),
('Z803','admin-id','Bank Charges (-)','Expenditure','Out','Internal',1,'admin-id','2026-01-10 08:06:45','admin-id','2026-01-10 08:06:45',1),
('Z804','admin-id','Bank Loan Payment (-)','Expenditure','Out','Internal',1,'admin-id','2026-01-10 08:06:45','admin-id','2026-01-10 08:06:45',1),
('Z805','admin-id','Other Cost (-)','Expenditure','Out','Internal',1,'admin-id','2026-01-10 08:06:45','admin-id','2026-01-10 08:06:45',1),
('Z901','admin-id','Rent (-)','Expense','Out','Internal',1,'admin-id','2026-01-10 08:06:39','admin-id','2026-01-10 08:06:39',1),
('Z902','admin-id','Rent Advance (-)','Expense','Out','Internal',1,'admin-id','2026-01-10 08:06:39','admin-id','2026-01-10 08:06:39',1),
('Z903','admin-id','Electricity Bill (-)','Expense','Out','Internal',1,'admin-id','2026-01-10 08:06:39','admin-id','2026-01-10 08:06:39',1),
('Z904','admin-id','Internet Bill (-)','Expense','Out','Internal',1,'admin-id','2026-01-10 08:06:39','admin-id','2026-01-11 12:32:07',1),
('Z905','admin-id','Transport Bill (-)','Expense','Out','Internal',1,'admin-id','2026-01-10 08:06:39','admin-id','2026-01-10 08:06:39',1);
/*!40000 ALTER TABLE `tmtb_trhed` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmub_notes`
--

DROP TABLE IF EXISTS `tmub_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmub_notes` (
  `id` varchar(50) NOT NULL,
  `notes_users` varchar(50) NOT NULL,
  `notes_title` varchar(100) NOT NULL,
  `notes_descr` varchar(500) DEFAULT NULL,
  `notes_dudat` datetime NOT NULL DEFAULT current_timestamp(),
  `notes_stat` varchar(50) DEFAULT 'In Progress',
  `notes_actve` tinyint(1) NOT NULL DEFAULT 1,
  `notes_crusr` varchar(50) NOT NULL,
  `notes_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `notes_upusr` varchar(50) NOT NULL,
  `notes_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `notes_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmub_notes`
--

LOCK TABLES `tmub_notes` WRITE;
/*!40000 ALTER TABLE `tmub_notes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tmub_notes` VALUES
('6e9a94bf-a9ec-4d3f-9ed1-e0da18c1c0f9','admin-id','Development in Progress','Development in Progress','2026-01-15 01:56:00','Scheduled',0,'admin-id','2026-01-14 07:58:44','admin-id','2026-01-28 06:32:17',6);
/*!40000 ALTER TABLE `tmub_notes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tmub_tickt`
--

DROP TABLE IF EXISTS `tmub_tickt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmub_tickt` (
  `id` varchar(50) NOT NULL,
  `tickt_users` varchar(50) NOT NULL,
  `tickt_types` varchar(50) NOT NULL,
  `tickt_cmnte` varchar(300) NOT NULL,
  `tickt_cmdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tickt_rsnte` varchar(300) DEFAULT NULL,
  `tickt_rspnt` int(11) NOT NULL DEFAULT 0,
  `tickt_cmsts` varchar(50) DEFAULT 'Opened',
  `tickt_rsdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tickt_actve` tinyint(1) NOT NULL DEFAULT 1,
  `tickt_crusr` varchar(50) NOT NULL,
  `tickt_crdat` datetime NOT NULL DEFAULT current_timestamp(),
  `tickt_upusr` varchar(50) NOT NULL,
  `tickt_updat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tickt_rvnmr` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmub_tickt`
--

LOCK TABLES `tmub_tickt` WRITE;
/*!40000 ALTER TABLE `tmub_tickt` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tmub_tickt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'shopdb'
--

--
-- Dumping routines for database 'shopdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-01-31  9:50:03
